---
marp: true
theme: default
paginate: true
title: Claude Code Foundations
description: Workshop 1 of 2 — Claude Code primitives for security engineers
---

<!--
This deck is authored in Marp markdown. Render with:
  npx @marp-team/marp-cli claude-code-foundations.md -o claude-code-foundations.pdf
or open in VS Code with the Marp extension.
-->

# Claude Code Foundations

Workshop 1 of 2 — for security engineers

*Today: the primitives. Workshop 2: threat modeling with the AITM plugin.*

---

## Why we're doing this

You're going to use a Claude Code plugin (AITM) to do real threat-modeling work.

Plugins are bundles of **primitives**. If you don't know the primitives, the plugin is a black box.

Today we open the box.

---

## Schedule (145 min)

| Slot | Module | Time |
|------|--------|------|
| Intro | Claude Code in 5 minutes | 5 min |
| 0 | Driving the REPL | 15 min |
| 1 | Mechanics | 18 min |
| 2 | Trust | 18 min |
| 3 | Context | 18 min |
| 4 | Extensibility | 18 min |
| 5 | Delegation | 23 min |
| 6 | Capstone | 25 min |
| Wrap | Workshop 2 preview | 5 min |

Each slot: I present (5–9 min), you do a lab (8–14 min). Module 0 is a live-along — no lab. Acceptance criteria are explicit.

---

## How to keep up

- Stay in the **terminal**, not the slides.
- Each module has a `README.md` — that IS the lab guide.
- Stuck for 5 min? Open `answers/<module>/SOLUTION.md`. The point is learning the primitive, not grinding on syntax.

---

# Intro: What is Claude Code?

---

## Not a chat box.

ChatGPT / Claude.ai: you paste, it responds.

Claude Code: you give it a goal — it **runs the loop**:

1. Picks a tool (`Read`, `Grep`, `Bash`, `Edit`, ...)
2. Runs it
3. Looks at the result
4. Picks the next tool
5. Loop until done

You're hiring a junior, not autocompleting.

---

## What changes for you (a security engineer)

| Old way | With Claude Code |
|---------|------------------|
| Grep + read + grep + read | "Find every place X happens and rate the risk" |
| `git log -S` for one symbol | "Trace the lifecycle of this token across the codebase" |
| Eyeball secrets | A custom slash command does it every time |
| One review at a time | Subagents run scans in parallel |

The leverage is real. So is the rope you can hang yourself with — that's why **Module 2 is Trust**.

---

# Module 0 — Driving the REPL

**Learning objective:** drive the Claude Code REPL — discover commands, manage your conversation, swap models, see costs, and reference files / shell from inside the prompt.

---

## Why this slide deck stops here

You'll spend the rest of the workshop **inside the REPL**, not on these slides.

These are the controls. 13 minutes of muscle memory now saves you fumbling for the next 2 hours.

This module is a **live-along** — I run a command, you run it on your machine. No lab, no acceptance criterion. The cheatsheet at `modules/00-commands/CHEATSHEET.md` is your takeaway.

---

## Discoverability & exit

```
/help      list every slash command
/status    current model, working dir, session state
/exit      leave the REPL (Ctrl-D / Ctrl-C twice also work)
```

When in doubt: `/help`. You don't need to memorize.

---

## Conversation hygiene

```
/clear     wipe the conversation, start fresh
/compact   summarize so far, keep going
```

| Situation | Reach for |
|-----------|-----------|
| New, unrelated task | `/clear` |
| Same task, context filling up | `/compact` |

Tokens cost time **and** quality. Hygiene matters.

---

## Model & cost

```
/model     switch Opus / Sonnet / Haiku
/cost      what this session has cost so far
```

Opus = capable + expensive. Haiku = fast + cheap. Sonnet = the middle.

Security teams notice both — capability *and* spend. Check `/cost` before you walk away.

---

## Driving inputs & outputs

Two non-slash shortcuts you'll use constantly:

```
@path/to/file    reference a file in your prompt (tab-completes)
!command         escape to a shell command without leaving the REPL
```

Examples:

```
> @sample-app/README.md what does this app do?
> !ls sample-app/routes/
```

Claude reads files via `@`. You stay in the conversation via `!`.

---

## Live-along (13 min)

| # | You type | Why |
|---|----------|-----|
| 1 | `cd sample-app && claude` | Launch the REPL |
| 2 | `/help` | See what's there |
| 3 | `/status` | Confirm model + working dir |
| 4 | `@README.md what does this app do?` | File reference, no paste |
| 5 | `!ls routes/` | Shell escape |
| 6 | `/model` → pick Sonnet | Cost vs. capability |
| 7 | `/cost` | What did this cost? |
| 8 | `/clear` | Reset for Module 1 |
| 9 | `/exit` | (instructor demos only — students **stay** in the REPL for Module 1) |

Stay in the REPL after step 8 — Module 1 starts there.

---

# Module 1 — Mechanics

**Learning objective:** use Claude Code to read & search a codebase like a security reviewer.

---

## The agentic loop

```
prompt ──▶ Claude picks a tool ──▶ tool runs ──▶ result
                  ▲                                   │
                  └───────── decides next ◀───────────┘
```

The tools you'll see most:
- **Read** — open a file
- **Grep** — regex search the repo
- **Glob** — list files matching a pattern
- **Bash** — run a shell command
- **Edit / Write** — modify files

You don't drive each step. Claude does.

---

## What this looks like

You: *"Find every place this app reads from the database. Tell me which look unsafe."*

Claude:
1. `Glob src/**/*.js` to find code files
2. `Grep "db\\." routes/` to find DB calls
3. `Read` each match to understand context
4. Returns: a list of file:line + why each is unsafe

You did one prompt. Claude did ~10 tool calls.

---

## Lab 1 — Be a security reviewer

Open `modules/01-mechanics/README.md`.

**Task:** in `sample-app/`, get Claude to find the unsafe DB reads. Save them to `lab/findings.md`.

**Acceptance:** ≥3 findings with `file:line — reason`.

**Time:** 10 min

🟢 Go.

---

# Module 2 — Trust

**Learning objective:** lock down what Claude can do via `settings.json`.

---

## Why you care

Claude can run shell commands.

You don't want to trust **per-prompt**. You want **policy**.

That policy is `settings.json`.

---

## The permission model

Three lists, checked on every tool call:

| List | Behavior |
|------|----------|
| `permissions.allow` | Auto-allow |
| `permissions.ask` | Prompt the user (default for unlisted) |
| `permissions.deny` | Block — no prompt |

Patterns: `"Bash"` (whole tool) or `"Bash(rm:*)"` (specific invocations).

**Deny always wins.**

---

## Settings hierarchy

| Scope | Path |
|-------|------|
| User (global) | `~/.claude/settings.json` |
| Project (shared) | `<project>/.claude/settings.json` |
| Project (local override) | `<project>/.claude/settings.local.json` |

More-specific overrides less-specific. Deny wins everywhere.

---

## Anti-pattern

```json
{ "permissions": { "allow": ["Bash"] } }
```

Don't do this. Auto-allow read tools. Leave Bash on `ask`. Deny what you know is bad.

---

## Lab 2 — Lock it down

Open `modules/02-trust/README.md`.

**Task:** write `sample-app/.claude/settings.json` that:
- auto-allows `Read`, `Grep`, `Glob`
- denies `Bash(rm:*)` and `Bash(curl:*)`

Then prove it: ask Claude to delete something. Watch the deny.

**Acceptance:** settings.json exists; `lab/proof.md` shows a denied attempt.

**Time:** 10 min

🟢 Go.

---

# Module 3 — Context

**Learning objective:** prime the model with `CLAUDE.md`.

---

## What does Claude actually see?

On every turn:

1. Claude Code's system prompt (you don't write this)
2. Your **CLAUDE.md** files
3. Your prompt
4. Tool results

You control 2 and 3. The biggest lever is CLAUDE.md.

---

## The CLAUDE.md hierarchy

| File | Scope |
|------|-------|
| `~/.claude/CLAUDE.md` | All your sessions |
| `<project>/CLAUDE.md` | This project |
| `<project>/<subdir>/CLAUDE.md` | Subset of project |

They **add** to each other. Lower-level doesn't override.

---

## What goes in a project CLAUDE.md

Things Claude **can't infer from one Read**:

- Stack + architecture style
- Where things live ("routes are in `src/routes/`")
- Security/coding conventions ("All SQL parameterized. No concatenation.")
- What NOT to touch
- Useful commands

Aim for **tight**. Every line is read every turn.

---

## Anti-pattern

200 lines of "everything you might want to know."

Claude reads it on every turn. Tokens cost time and quality.

Be ruthless.

---

## Lab 3 — Prime the model

Open `modules/03-context/README.md`.

**Task:**
1. Read the baseline transcript (no CLAUDE.md).
2. Write `sample-app/CLAUDE.md` with stack + locations + 3 security conventions + 1 "do not touch."
3. Run the same prompt. Compare. Write 2-3 sentences in `lab/observation.md`.

**Acceptance:** CLAUDE.md exists; observation.md filled.

**Time:** 10 min

🟢 Go.

---

# Module 4 — Extensibility

**Learning objective:** author a slash command and a hook.

---

## Custom slash commands

A reusable prompt, saved as a file.

```
.claude/commands/secret-scan.md
```

```markdown
---
description: Scan for hardcoded secrets.
---

Search this codebase for API keys, passwords...
```

Now in the REPL: `/secret-scan` runs that prompt.

---

## Hooks

Automated behaviors fired on lifecycle events.

| Event | When |
|-------|------|
| `PreToolUse` | Before any tool call |
| `PostToolUse` | After a tool call |
| `Stop` | When Claude finishes a turn |
| `UserPromptSubmit` | When you submit a prompt |

Configured in `settings.json`. Each hook is a **shell command** that gets event JSON on stdin.

---

## Audit hook example

```json
{
  "hooks": {
    "PreToolUse": [{
      "matcher": "Bash",
      "hooks": [{
        "type": "command",
        "command": "jq -r '.tool_input.command // empty' >> /tmp/audit.log"
      }]
    }]
  }
}
```

Now every Bash call is logged before it runs. Security teams call this "non-negotiable."

---

## Why this matters

Slash commands + hooks = **the building blocks of plugins**.

The AITM plugin you'll use in Workshop 2 is mostly:
- Slash commands (entry points)
- Hooks (state persistence)
- + Subagents + MCP (next module)
- + Knowledge files

You've now seen the first two.

---

## Lab 4 — Automate a security check

Open `modules/04-extensibility/README.md`.

**Task A:** write `sample-app/.claude/commands/secret-scan.md`. Run it.

**Task B:** add a `PreToolUse` Bash audit hook to `settings.json`. Trigger it. Read the log.

**Acceptance:** both files exist; both reports captured in `lab/`.

**Time:** 10 min

🟢 Go.

---

# Module 5 — Delegation

**Learning objective:** use subagents to scale; install an MCP.

---

## Two ways to extend Claude

| Primitive | What it adds |
|-----------|--------------|
| **Subagent** | A specialized agent with its **own context** |
| **MCP server** | New **tools and data sources** |

Subagents = delegate agentic work.
MCPs = add tools and data.

---

## The context-bloat problem

Ask the main thread:
> *"Find every place this app reads env vars and rate the risk."*

Claude:
1. Greps the repo
2. **Reads every match into the parent context**
3. Summarizes

In a 30-file repo, step 2 fills your context. Tokens spike. Later turns get worse.

---

## Subagent: the clean way

```
parent ─▶ dispatch subagent ─▶ subagent reads 30 files ─▶ summary
                                in ITS OWN context
```

Parent receives a summary. Stays clean.

---

## What a subagent file looks like

`.claude/agents/env-auditor.md`:

```markdown
---
name: env-auditor
description: Find env-var reads and rate risk.
tools: Read, Grep, Glob
---

You are an env-var auditor. Return ONLY a markdown table.
Do NOT return raw file contents to the parent.
```

The subagent has its own system prompt, tools, and context.

---

## When to reach for a subagent

- Task touches many files
- Task needs specialized instructions
- Task can run in parallel with other work
- You want the **result**, not the process

---

## MCP — extending tools and data

Model Context Protocol. Configured in `.mcp.json`.

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"]
    }
  }
}
```

Now Claude has `mcp__filesystem__read_file`, `mcp__filesystem__write_file`, etc.

---

## What MCPs we'll touch

- **Today (lab):** the public **filesystem MCP** — works out of the box
- **Workshop 2 (AITM):** **Sunrise MCP** (internal) for app metadata, **Jira MCP** for ticket creation

> *Instructor note: if Sunrise MCP is wired up for this room, demo it now. Otherwise the filesystem MCP is the working default.*

---

## Lab 5 — Two ways to extend

Open `modules/05-delegation/README.md`.

**Part A:** in `sample-large-app/`, run an env-var audit twice — main thread vs subagent. Compare in `lab/comparison.md`.

**Part B:** install the filesystem MCP. Verify with `/mcp`. Use it. Capture proof in `lab/mcp-proof.md`.

**Acceptance:** both labs produce their output files.

**Time:** 12 min

🟢 Go.

---

# Module 6 — Capstone

**Learning objective:** install a plugin, dissect it, recognize the primitives.

---

## A plugin = bundled primitives

| Plugin file | Primitive |
|-------------|-----------|
| `commands/<name>.md` | Slash command (M4) |
| `agents/<name>.md` | Subagent (M5) |
| `settings.json` permissions | Trust (M2) |
| `settings.json` hooks | Hook (M4) |
| `.mcp.json` | MCP (M5) |
| `CLAUDE.md` | Context (M3) |

That's it. Plugins are zip files of stuff you've already learned to write.

---

## What you'll install

`security-quickscan` — a small plugin in `modules/06-capstone/sample-plugin/`.

It has:
- 1 slash command (`/quickscan`)
- 1 subagent (`vuln-finder`)
- 1 hook (Bash audit)
- 1 CLAUDE.md
- Permission rules

Five primitives. Same shape as AITM, much smaller.

---

## Lab 6 — Install & dissect

Open `modules/06-capstone/README.md`.

**Task:**
1. Install the plugin into `sample-app/`.
2. Run `/quickscan`. Read the report.
3. Open every plugin file. Map each one to a primitive in `lab/plugin-anatomy.md`.

**Acceptance:** plugin runs; `quickscan-report.md` exists; anatomy doc filled.

**Time:** 20 min

🟢 Go.

---

# Wrap

---

## You now know

- The agentic loop and the core tools
- Permissions and `settings.json`
- CLAUDE.md and context engineering
- Custom slash commands
- Hooks
- Subagents and when to use them
- MCP servers
- How a plugin composes all of these

That's the whole foundation.

---

## Workshop 2 preview — AITM

The threat-modeling plugin uses **all** of today's primitives at scale:

- 9-phase orchestrated workflow (slash commands)
- ~11 specialized subagents (per-phase, per-domain)
- Hooks for state persistence (resume across sessions)
- MCP integrations (Sunrise, Jira)
- OWASP knowledge files
- Human checkpoints

When you read its source, you should now recognize the shape.

---

## Before next time

- Skim `threat-modeling-plugin/README.md` and `threat-modeling-plugin/workflow.md` if you have access
- Try `/secret-scan` and `/quickscan` on a real (non-production) repo of yours
- Pre-flight Workshop 2 (will be sent separately)

---

# Questions?

Stay in this repo. Reference solutions are in `answers/`. Come back when you forget how a slash command's frontmatter looks.
