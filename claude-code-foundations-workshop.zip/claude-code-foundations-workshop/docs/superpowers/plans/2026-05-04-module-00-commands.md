# Module 00 — Driving the REPL Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a 15-minute "Module 00 — Driving the REPL" to the Claude Code Foundations workshop, covering basic in-REPL slash commands and input shortcuts before Module 1 begins.

**Architecture:** Three changes — (1) one new cheatsheet file at `modules/00-commands/CHEATSHEET.md`, (2) edits to `slides/claude-code-foundations.md` to add seven new Marp slides and update the schedule, (3) edits to `README.md` to update the schedule, top-line description, and per-module workflow note. No code, no tests — this is workshop content.

**Tech Stack:** Markdown, Marp (Marp markdown for slides). Workshop dir is NOT a git repository — verification is by reading back the file and (optionally) rendering the Marp slides via `npx @marp-team/marp-cli`.

**Spec:** `docs/superpowers/specs/2026-05-04-module-00-commands-design.md`

---

## File Structure

| File | Action | Responsibility |
|------|--------|----------------|
| `modules/00-commands/CHEATSHEET.md` | Create | Single-page reference of in-REPL commands students learn in M0 |
| `slides/claude-code-foundations.md` | Modify | Add 7 slides for M0 between existing Intro and Module 1; update schedule table |
| `README.md` | Modify | Update top-line description, schedule table, and workflow note for M0's lab-less format |

---

## Task 1: Create the cheatsheet

**Files:**
- Create: `modules/00-commands/CHEATSHEET.md`

- [ ] **Step 1: Verify directory does not yet exist**

Run: `ls modules/00-commands/ 2>&1`
Expected: `ls: modules/00-commands/: No such file or directory` (or equivalent)

- [ ] **Step 2: Create the cheatsheet file**

Write the file `modules/00-commands/CHEATSHEET.md` with exactly this content:

```markdown
# Module 0 — Driving the REPL: Cheatsheet

The universal in-REPL controls. Run any of these from inside `claude`.

> Module 0 is a **live-along** — there's no graded lab. This file is your reference for the rest of the workshop and after.

---

## Discoverability & exit

| Command | What it does |
|---------|--------------|
| `/help` | List every available slash command. Skim it once; you don't need to memorize. |
| `/status` | Show the current model, working directory, and session state. |
| `/exit` | Leave the REPL cleanly. `Ctrl-D` (EOF) and `Ctrl-C` twice also work. |

---

## Conversation hygiene

| Command | What it does |
|---------|--------------|
| `/clear` | Wipe the conversation. Start fresh. Use this between unrelated tasks. |
| `/compact` | Summarize the conversation so far and keep going. Use when context is full but the work isn't. |

**Rule of thumb:** new task → `/clear`. Same task, running long → `/compact`.

---

## Model & cost

| Command | What it does |
|---------|--------------|
| `/model` | Switch between Opus, Sonnet, and Haiku. Faster/cheaper vs. more capable. |
| `/cost` | Show what this session has cost so far. Security teams care; check it. |

---

## Input shortcuts (not slash commands, but you'll use them constantly)

| Shortcut | What it does |
|----------|--------------|
| `@path/to/file` | Reference a file in your prompt. Claude reads it without you pasting. Tab-completes. |
| `!command` | Escape to a shell command without leaving the REPL. Output stays in the conversation. |

Example:
```
> @sample-app/README.md what does this app do?
> !ls sample-app/routes/
```

---

## Covered later in the workshop

These commands exist; you'll learn each one in its own module.

| Command | Module |
|---------|--------|
| `/permissions` | Module 2 — Trust |
| `/init`, `#memory` | Module 3 — Context |
| `/agents` | Module 5 — Delegation |
| `/mcp` | Module 5 — Delegation |
| `/plugin` | Module 6 — Capstone |
```

- [ ] **Step 3: Verify the file exists and renders**

Run: `ls modules/00-commands/CHEATSHEET.md && wc -l modules/00-commands/CHEATSHEET.md`
Expected: file exists, ~60 lines.

Run: `head -5 modules/00-commands/CHEATSHEET.md`
Expected: shows the title `# Module 0 — Driving the REPL: Cheatsheet` and the lead paragraph.

---

## Task 2: Update the slides schedule table

**Files:**
- Modify: `slides/claude-code-foundations.md:33-46` (the `## Schedule (130 min)` heading and table)

- [ ] **Step 1: Read current schedule slide to confirm line range**

Run: `sed -n '33,46p' slides/claude-code-foundations.md`
Expected: shows the heading `## Schedule (130 min)` and an 8-row table from `Intro` to `Wrap`.

- [ ] **Step 2: Replace the heading and table**

Use Edit on `slides/claude-code-foundations.md`. Replace this block:

```markdown
## Schedule (130 min)

| Slot | Module | Time |
|------|--------|------|
| Intro | Claude Code in 5 minutes | 5 min |
| 1 | Mechanics | 18 min |
| 2 | Trust | 18 min |
| 3 | Context | 18 min |
| 4 | Extensibility | 18 min |
| 5 | Delegation | 23 min |
| 6 | Capstone | 25 min |
| Wrap | Workshop 2 preview | 5 min |

Each slot: I present (5–9 min), you do a lab (8–14 min). Acceptance criteria are explicit.
```

With:

```markdown
## Schedule (145 min)

| Slot | Module | Time |
|------|--------|------|
| Intro | Claude Code in 5 minutes | 5 min |
| 0 | Driving the REPL | 15 min |
| 1 | Mechanics | 18 min |
| 2 | Trust | 18 min |
| 3 | Context | 18 min |
| 4 | Extensibility | 18 min |
| 5 | Delegation | 23 min |
| 6 | Capstone | 25 min |
| Wrap | Workshop 2 preview | 5 min |

Each slot: I present (5–9 min), you do a lab (8–14 min). Module 0 is a live-along — no lab. Acceptance criteria are explicit.
```

- [ ] **Step 3: Verify the change**

Run: `grep -n "Schedule (145 min)" slides/claude-code-foundations.md`
Expected: one match around line 33.

Run: `grep -n "Driving the REPL" slides/claude-code-foundations.md`
Expected: one match in the schedule table.

---

## Task 3: Insert the seven Module 0 slides

**Files:**
- Modify: `slides/claude-code-foundations.md` — insert after the `---` separator that follows the `## What changes for you` slide, before the `# Module 1 — Mechanics` heading. The original separator was at line 89; after Task 2 the line number is unchanged because Task 2 added one row inside an existing table.

- [ ] **Step 1: Locate the insertion point**

Run: `grep -n "^# Module 1 — Mechanics" slides/claude-code-foundations.md`
Expected: one match, around line 91.

Run: `sed -n '85,92p' slides/claude-code-foundations.md`
Expected: shows the end of the "What changes for you" slide, then `---` separator, then `# Module 1 — Mechanics`.

- [ ] **Step 2: Insert the seven new slides**

Use Edit on `slides/claude-code-foundations.md`. Replace this block (which is the existing transition into Module 1):

```markdown
The leverage is real. So is the rope you can hang yourself with — that's why **Module 2 is Trust**.

---

# Module 1 — Mechanics
```

With:

```markdown
The leverage is real. So is the rope you can hang yourself with — that's why **Module 2 is Trust**.

---

# Module 0 — Driving the REPL

**Learning objective:** drive the Claude Code REPL — discover commands, manage your conversation, swap models, see costs, and reference files / shell from inside the prompt.

---

## Why this slide deck stops here

You'll spend the rest of the workshop **inside the REPL**, not on these slides.

These are the controls. 13 minutes of muscle memory now saves you fumbling for the next 2 hours.

This module is a **live-along** — I run a command, you run it on your machine. No lab, no acceptance criterion. The cheatsheet at `modules/00-commands/CHEATSHEET.md` is your takeaway.

---

## Discoverability & exit

```
/help      list every slash command
/status    current model, working dir, session state
/exit      leave the REPL (Ctrl-D / Ctrl-C twice also work)
```

When in doubt: `/help`. You don't need to memorize.

---

## Conversation hygiene

```
/clear     wipe the conversation, start fresh
/compact   summarize so far, keep going
```

| Situation | Reach for |
|-----------|-----------|
| New, unrelated task | `/clear` |
| Same task, context filling up | `/compact` |

Tokens cost time **and** quality. Hygiene matters.

---

## Model & cost

```
/model     switch Opus / Sonnet / Haiku
/cost      what this session has cost so far
```

Opus = capable + expensive. Haiku = fast + cheap. Sonnet = the middle.

Security teams notice both — capability *and* spend. Check `/cost` before you walk away.

---

## Driving inputs & outputs

Two non-slash shortcuts you'll use constantly:

```
@path/to/file    reference a file in your prompt (tab-completes)
!command         escape to a shell command without leaving the REPL
```

Examples:

```
> @sample-app/README.md what does this app do?
> !ls sample-app/routes/
```

Claude reads files via `@`. You stay in the conversation via `!`.

---

## Live-along (13 min)

| # | You type | Why |
|---|----------|-----|
| 1 | `cd sample-app && claude` | Launch the REPL |
| 2 | `/help` | See what's there |
| 3 | `/status` | Confirm model + working dir |
| 4 | `@README.md what does this app do?` | File reference, no paste |
| 5 | `!ls routes/` | Shell escape |
| 6 | `/model` → pick Sonnet | Cost vs. capability |
| 7 | `/cost` | What did this cost? |
| 8 | `/clear` | Reset for Module 1 |
| 9 | `/exit` | (instructor demos only — students **stay** in the REPL for Module 1) |

Stay in the REPL after step 8 — Module 1 starts there.

---

# Module 1 — Mechanics
```

- [ ] **Step 3: Verify the insertion**

Run: `grep -n "^# Module 0 — Driving the REPL" slides/claude-code-foundations.md`
Expected: one match.

Run: `grep -c "^---" slides/claude-code-foundations.md`
Expected: original count + 7 (seven new slide separators added).

Run: `grep -n "^# Module 1 — Mechanics" slides/claude-code-foundations.md`
Expected: still exactly one match, now further down the file.

- [ ] **Step 4 (optional): Render the slides to confirm Marp parses cleanly**

Run: `cd slides && npx @marp-team/marp-cli claude-code-foundations.md -o /tmp/check.pdf 2>&1 | tail -5`
Expected: no errors. If `npx` isn't available locally, skip this step — visual inspection of the markdown is sufficient.

---

## Task 4: Update the README

**Files:**
- Modify: `README.md:3` (top-line description)
- Modify: `README.md:17-30` (schedule heading, table, and trailing rhythm note)
- Modify: `README.md:48-53` (workflow per module — add M0 note)

- [ ] **Step 1: Update the top-line description**

Use Edit on `README.md`. Replace:

```markdown
A 2-hour, hands-on workshop for **security engineers** who have never used Claude Code. By the end you'll be comfortable with the primitives — permissions, context, slash commands, hooks, subagents, MCPs, and plugins — that power agentic security tooling like the AITM threat-modeling plugin (Workshop 2).
```

With:

```markdown
A 2h 25min, hands-on workshop for **security engineers** who have never used Claude Code. By the end you'll be comfortable with the primitives — permissions, context, slash commands, hooks, subagents, MCPs, and plugins — that power agentic security tooling like the AITM threat-modeling plugin (Workshop 2).
```

- [ ] **Step 2: Update the schedule heading, table, and rhythm note**

Use Edit on `README.md`. Replace this block:

```markdown
## Schedule (130 minutes)

| Slot | Module | Time |
|------|--------|------|
| — | Intro: what is Claude Code | 5 min |
| 1 | [Mechanics](./modules/01-mechanics/) — agentic loop + reading code | 18 min |
| 2 | [Trust](./modules/02-trust/) — permissions + settings.json | 18 min |
| 3 | [Context](./modules/03-context/) — CLAUDE.md + context engineering | 18 min |
| 4 | [Extensibility](./modules/04-extensibility/) — slash commands + hooks | 18 min |
| 5 | [Delegation](./modules/05-delegation/) — subagents + MCP servers | 23 min |
| 6 | [Capstone](./modules/06-capstone/) — install & dissect a plugin | 25 min |
| — | Wrap-up + Workshop 2 preview | 5 min |

Each module follows the same rhythm: instructor presents the concept (≈5–9 min), then you do a lab (≈8–14 min). Acceptance criteria are explicit — you finish a lab when the named output file exists with the right content.
```

With:

```markdown
## Schedule (145 minutes)

| Slot | Module | Time |
|------|--------|------|
| — | Intro: what is Claude Code | 5 min |
| 0 | [Driving the REPL](./modules/00-commands/CHEATSHEET.md) — slash commands + input shortcuts | 15 min |
| 1 | [Mechanics](./modules/01-mechanics/) — agentic loop + reading code | 18 min |
| 2 | [Trust](./modules/02-trust/) — permissions + settings.json | 18 min |
| 3 | [Context](./modules/03-context/) — CLAUDE.md + context engineering | 18 min |
| 4 | [Extensibility](./modules/04-extensibility/) — slash commands + hooks | 18 min |
| 5 | [Delegation](./modules/05-delegation/) — subagents + MCP servers | 23 min |
| 6 | [Capstone](./modules/06-capstone/) — install & dissect a plugin | 25 min |
| — | Wrap-up + Workshop 2 preview | 5 min |

Most modules follow the same rhythm: instructor presents the concept (≈5–9 min), then you do a lab (≈8–14 min). Acceptance criteria are explicit — you finish a lab when the named output file exists with the right content. **Module 0 is the exception**: it's a guided live-along with no lab — the takeaway is the cheatsheet.
```

- [ ] **Step 3: Update the workflow-per-module section to flag M0's no-lab format**

Use Edit on `README.md`. Replace:

```markdown
**Workflow per module:**
1. Listen to the instructor's presentation.
2. Open `modules/<NN-name>/README.md` and follow the lab steps.
3. Work in `modules/<NN-name>/lab/` (your starter files live there).
4. When you hit the acceptance criterion (or get stuck for 5 minutes), open `answers/<NN-name>/SOLUTION.md`.
5. Move on.

**Rule of thumb:** if you're stuck for more than 5 minutes, open the answer. The point is to *learn the primitive*, not to grind on syntax.
```

With:

```markdown
**Workflow per module:**
1. Listen to the instructor's presentation.
2. Open `modules/<NN-name>/README.md` and follow the lab steps.
3. Work in `modules/<NN-name>/lab/` (your starter files live there).
4. When you hit the acceptance criterion (or get stuck for 5 minutes), open `answers/<NN-name>/SOLUTION.md`.
5. Move on.

**Module 0 exception:** no `README.md`, no `lab/`, no `answers/`. It's a live-along — the instructor demos commands, you run them in real time. Reference: `modules/00-commands/CHEATSHEET.md`.

**Rule of thumb:** if you're stuck for more than 5 minutes, open the answer. The point is to *learn the primitive*, not to grind on syntax.
```

- [ ] **Step 4: Verify the README changes**

Run: `grep -n "2h 25min" README.md`
Expected: one match at line 3.

Run: `grep -n "Schedule (145 minutes)" README.md`
Expected: one match.

Run: `grep -n "Driving the REPL" README.md`
Expected: one match in the schedule table.

Run: `grep -n "Module 0 exception" README.md`
Expected: one match in the workflow section.

---

## Task 5: Final integration check

**Files:**
- All four files from prior tasks.

- [ ] **Step 1: Confirm all files are in place**

Run: `ls modules/00-commands/CHEATSHEET.md slides/claude-code-foundations.md README.md docs/superpowers/specs/2026-05-04-module-00-commands-design.md`
Expected: all four paths print.

- [ ] **Step 2: Confirm slide and README schedules agree**

Run: `grep "Schedule" slides/claude-code-foundations.md README.md`
Expected: slides shows `## Schedule (145 min)`, README shows `## Schedule (145 minutes)`. Both reference 145 — units differ but values match the spec.

- [ ] **Step 3: Confirm cross-references work**

Run: `grep -n "modules/00-commands/CHEATSHEET.md" slides/claude-code-foundations.md README.md`
Expected: at least one match in each file.

- [ ] **Step 4: Cross-check time math**

The schedule must sum to 145 min: 5 (Intro) + 15 (M0) + 18 + 18 + 18 + 18 + 23 + 25 + 5 = 145. ✓

Run: `grep -E "^\| (Intro|0|1|2|3|4|5|6|Wrap|—)" README.md | grep -oE '[0-9]+ min' | awk '{sum += $1} END {print sum}'`
Expected: `145`

---

## Notes

- **No git commits.** The workshop directory is not a git repository. If the user later initializes one, they can squash these changes into a commit named e.g. `feat: add Module 0 — Driving the REPL`.
- **No tests.** This is workshop content, not code. Verification is by reading back the files and (optionally) rendering the Marp slides.
- **Forward references in M0 slides.** The slides intentionally don't cover `/permissions`, `/init`, `#memory`, `/agents`, `/mcp`, `/plugin` — each is the subject of a later module. The cheatsheet's "Covered later" section signposts them.
