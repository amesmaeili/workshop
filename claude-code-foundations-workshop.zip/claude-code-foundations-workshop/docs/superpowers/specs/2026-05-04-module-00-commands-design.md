# Module 00 — Driving the REPL (design)

**Date:** 2026-05-04
**Status:** Approved (pending implementation plan)
**Workshop:** Claude Code Foundations (Workshop 1 of 2)

## Problem

The current workshop opens with a 5-minute "What is Claude Code?" intro that introduces the agentic loop, then drops students directly into Module 1 (Mechanics). Students arrive at Module 1 without ever having driven the REPL — they don't know how to discover commands, manage their conversation context, swap models, see costs, or use the `@file` / `!shell` input shortcuts. The result is friction in every later module: students fumble basic controls while trying to learn higher-order primitives.

## Goal

Add a new **Module 00 — Driving the REPL** that gives students hands-on familiarity with the universal in-REPL controls before Module 1, so the rest of the workshop assumes a baseline of "I can drive Claude Code" rather than building it implicitly.

## Non-goals

- Teaching CLI invocation flags (`claude -p`, `--resume`, `--continue`, etc.) — out of scope for this module; PREFLIGHT.md already covers launching `claude`.
- Re-covering anything that is the subject of a later module: `/permissions` (M2), `/init` and `#memory` (M3), `/agents` and `/mcp` (M5), `/plugin` (M6). These get one-line forward-references only.
- Producing a graded lab artifact. Module 00 is a live-along; the deliverable is muscle memory.

## Design

### Schedule change

Workshop grows from 130 min to 145 min. The new schedule:

| Slot | Module | Time |
|------|--------|------|
| Intro | Claude Code in 5 minutes | 5 min |
| **0** | **Driving the REPL — slash commands & input shortcuts** | **15 min** |
| 1 | Mechanics | 18 min |
| 2 | Trust | 18 min |
| 3 | Context | 18 min |
| 4 | Extensibility | 18 min |
| 5 | Delegation | 23 min |
| 6 | Capstone | 25 min |
| Wrap | Workshop 2 preview | 5 min |

Total: 145 min (2h 25m).

### Format

**Guided live-along.** Instructor demos each command; students execute it on their own machine in parallel. No `lab/` directory, no acceptance criterion, no `answers/00-commands/`. Lower friction than a graded lab while still putting hands on keys before Module 1.

### Learning objective

By the end of Module 00, students can:
- Launch Claude Code and discover available commands
- Manage conversation context with `/clear` and `/compact`
- Swap models and check session cost
- Reference files with `@` and run shell commands with `!` from inside the REPL
- Exit cleanly

### Slides (added to `slides/claude-code-foundations.md`)

Inserted between the existing `## What changes for you` slide and `# Module 1 — Mechanics`. Seven new slides:

1. **Title slide** — "Module 0 — Driving the REPL" + learning objective.
2. **Why this matters** — you'll spend the rest of the workshop in the REPL; these are the controls.
3. **Discoverability & exit** — `/help`, `/status`, `/exit` (+ Ctrl-C, Ctrl-D as fallbacks).
4. **Conversation hygiene** — `/clear` (start fresh), `/compact` (summarize + free tokens). When to reach for which.
5. **Model & cost** — `/model` (swap Opus/Sonnet/Haiku), `/cost` (see what you've spent this session). Frame: security teams care about both.
6. **Driving inputs/outputs** — `@file` (reference a file in your prompt), `!shell` (escape to a shell command without leaving the REPL). Two-line demo each.
7. **Cheatsheet pointer** — points at `modules/00-commands/CHEATSHEET.md` for later reference.

### Live-along script

Instructor calls out, students follow. Sequence chosen so each step builds on state from the previous one and ends with a clean session ready for Module 1.

| # | Step | Command | Beat |
|---|------|---------|------|
| 1 | Launch | `cd sample-app && claude` | "You're in the REPL." |
| 2 | Discover | `/help` | "Skim — these all exist." |
| 3 | Status check | `/status` | "Confirm model + working dir." |
| 4 | Reference a file | `@README.md what does this app do?` | "Note Claude reads it without you pasting." |
| 5 | Shell escape | `!ls routes/` | "You don't have to leave the REPL to grep around." |
| 6 | Switch model | `/model` | "Pick Sonnet. Why? Cost vs. capability." |
| 7 | Check spend | `/cost` | "Now you know what this session cost." |
| 8 | Free context | `/clear` | "Reset for Module 1." |
| 9 | Exit | `/exit` | Demoed only; students stay in the REPL for Module 1. |

### Cheatsheet (`modules/00-commands/CHEATSHEET.md`)

Single-page reference. Sections:

- **Discoverability & exit:** `/help`, `/status`, `/exit` (+ Ctrl-C, Ctrl-D)
- **Conversation hygiene:** `/clear`, `/compact` (with one-line "when to use which" note)
- **Model & cost:** `/model`, `/cost`
- **Input shortcuts:** `@file`, `!shell`
- **What's covered later:** one-line pointers to `/permissions` (M2), `/init` + `#memory` (M3), `/agents` + `/mcp` (M5), `/plugin` (M6)

This is the only persistent artifact from the module. Students will come back to it; design accordingly (compact, scannable, one-screen).

## Files changed

**Created (1):**
- `modules/00-commands/CHEATSHEET.md`

**Edited (2):**
- `slides/claude-code-foundations.md`:
  - Insert 7 slides between current `## What changes for you` and `# Module 1 — Mechanics`
  - Update `## Schedule (130 min)` heading and table to reflect 145 min and the new M0 row
- `README.md`:
  - Update top-line "2-hour, hands-on workshop" → "2h 25min, hands-on workshop"
  - Update `## Schedule (130 minutes)` → `## Schedule (145 minutes)`, insert M0 row pointing to `modules/00-commands/CHEATSHEET.md`
  - Add note in **Workflow per module** that Module 0 is a live-along with no lab — `CHEATSHEET.md` is the takeaway

**Not created:**
- No `modules/00-commands/README.md` (cheatsheet-only structure)
- No `modules/00-commands/lab/` (no lab)
- No `answers/00-commands/` (nothing to solve)

## Out-of-scope choices (with rationale)

- **No CLI flag coverage.** Launching `claude` is in PREFLIGHT.md; flags like `--resume` are post-workshop self-service.
- **No `#memory`.** Covered properly in Module 3 alongside the CLAUDE.md hierarchy. Introducing it twice dilutes both.
- **No `/permissions`, `/agents`, `/mcp`, `/plugin`, `/init`.** Each is the subject of a later module; M0 just signposts them.
- **No graded lab.** At 15 min, a graded lab would crowd out the live-along. Muscle memory is the deliverable.

## Open questions

None at design time. All decisions made during brainstorming.
