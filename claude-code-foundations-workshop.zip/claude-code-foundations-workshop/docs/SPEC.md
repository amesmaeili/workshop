# Claude Code Foundations Workshop — Design Spec

**Date:** 2026-05-04
**Audience:** Security engineers (CLI/scripting/git proficient; have used ChatGPT/Cursor/Copilot casually; never used Claude Code)
**Format:** 2-hour, in-person, instructor-led, SANS-style (concept presentation → hands-on lab per module)
**Prerequisite to:** Workshop 2 — Threat Modeling with the AITM Plugin (separate workshop)

---

## 1. Purpose & Outcomes

By the end of this workshop, attendees can:

1. Explain how Claude Code differs from chat-based LLM tools (agentic loop, tool use, file edits).
2. Use Claude Code to read and search a codebase like a security reviewer.
3. Constrain Claude Code's tool access via `settings.json` permissions.
4. Author a `CLAUDE.md` to prime the model on a project's conventions.
5. Author a custom slash command.
6. Author a hook that runs on tool events.
7. Dispatch a subagent to keep the parent context focused, and explain when to use one.
8. Configure and verify an MCP server.
9. Install a Claude Code plugin and identify how it composes the primitives above.

Non-goals: threat modeling, the AITM plugin specifics, advanced prompt engineering theory, deep MCP server authoring.

---

## 2. Audience & Delivery

- **Skill baseline:** comfortable with terminal, scripting (bash/python), git; familiar with chat-based LLM tools but new to agentic CLIs.
- **Group:** in-person workshop, instructor presents then attendees do labs at their own pace within the timebox.
- **Pre-flight:** attendees install Claude Code, complete auth, and clone the workshop repo *one week before* the workshop. A `PREFLIGHT.md` checklist is sent ahead.
- **Cold-start mitigation:** the `PREFLIGHT.md` includes a "verify your install" command that produces a copy-paste-able output. Attendees who didn't pre-flight can still join but will fall behind.

---

## 3. Repository Layout

```
claude-code-foundations-workshop/
├── README.md                     # Workshop overview, schedule, how to use this repo
├── PREFLIGHT.md                  # Sent 1 week before; install + verify steps
├── docs/
│   └── SPEC.md                   # This document
├── slides/
│   └── claude-code-foundations.md   # Marp markdown
├── modules/
│   ├── 01-mechanics/             # Each: README.md (concept + lab) + lab/ starter files
│   ├── 02-trust/
│   ├── 03-context/
│   ├── 04-extensibility/
│   ├── 05-delegation/
│   └── 06-capstone/
├── answers/
│   ├── 01-mechanics/             # Each: SOLUTION.md + solution-files/
│   ├── ...
│   └── 06-capstone/
├── sample-app/                   # Small vulnerable Express app (used by M1-M4 + capstone)
└── sample-large-app/             # ~30-file mid-size Node service (used by M5)
```

**Format choices:**
- Slides authored as Marp markdown so they version-control cleanly and export to PDF/HTML.
- `answers/` is a sibling of `modules/` (not a subdirectory) so attendees aren't tempted to peek mid-lab.
- Each module README is self-contained: attendees can do labs without re-opening slides.

---

## 4. Schedule

| Slot | Module | Time |
|------|--------|------|
| - | Intro / what is Claude Code | 5 min |
| 1 | **Mechanics** — agentic loop + reading/searching code | 18 min |
| 2 | **Trust** — permissions + settings.json | 18 min |
| 3 | **Context** — CLAUDE.md + context engineering | 18 min |
| 4 | **Extensibility** — slash commands + hooks | 18 min |
| 5 | **Delegation** — subagents (with scale demo) + MCP install | 23 min |
| 6 | **Capstone** — install & dissect a sample plugin | 25 min |
| - | Wrap-up + Workshop 2 preview | 5 min |
| | **Total** | **130 min** |

If timing slips, M5 Lab Part B (MCP install) is the trim point — it can be demoed by the instructor instead of done hands-on. Module 6 capstone is protected.

---

## 5. Module Specifications

Each module follows: **lecture (5–9 min) → lab (8–14 min) → acceptance check.** Acceptance is always a file the attendee produces, so the instructor can spot-check without watching every screen.

### Module 1 — Mechanics (18 min)
Concept: agentic loop, tools (Read/Grep/Bash/Edit), file editing.
Lab: in `sample-app/`, ask Claude to find SQL-injection-prone reads. Output: `lab/findings.md` with file:line list.

### Module 2 — Trust (18 min)
Concept: permission model (allow/ask/deny), `settings.json` scopes (user vs project), why security folks care.
Lab: write `.claude/settings.json` for `sample-app/` that auto-allows read-only tools, asks before Bash, denies `rm` and `curl`. Verify by attempting a denied operation.

### Module 3 — Context (18 min)
Concept: what the model sees, CLAUDE.md hierarchy, anti-patterns.
Lab: write `sample-app/CLAUDE.md`. Run a fresh prompt with vs without it (a saved transcript is provided for the "without" baseline). Output: `lab/observation.md`.

### Module 4 — Extensibility (18 min)
Concept: slash commands as reusable prompts, hooks as automated behavior, how they compose into plugins.
Lab: author `.claude/commands/secret-scan.md` and a PreToolUse hook that audit-logs Bash calls. Verify both fire.

### Module 5 — Delegation (23 min)
Concept: when subagents help (context bloat at scale), MCP as tool/data extension.
- **Lab Part A (subagents at scale):** in `sample-large-app/`, run an env-var audit twice — once in main thread, once via a provided `env-auditor` subagent. Compare in `lab/comparison.md`.
- **Lab Part B (MCP install):** install the **filesystem MCP** (public, works out of the box) into the project's `.mcp.json`; verify with `/mcp`.
  - Includes a clearly-marked **"Replace with Sunrise MCP"** template section: placeholders for the internal install command, server URL, auth. Instructor swaps these in before delivering the workshop.

### Module 6 — Capstone (25 min)
Concept: a plugin is a packaged bundle of all 5 primitives.
Lab: install the provided `security-quickscan` plugin into `sample-app/`. Run `/quickscan`. Inspect the plugin's source files and fill in `lab/plugin-anatomy.md` mapping each file to the primitive it represents.

---

## 6. Sample Codebases

### `sample-app/` (10–15 files)
Realistic small Express + SQLite app simulating an internal tool. Intentional security issues:
- Hardcoded API key in source
- SQL string concatenation (injection)
- Missing authz check on an admin route
- `child_process.exec` with user input
- Logs that leak PII

Used by Modules 1, 2, 3, 4, and capstone. Same codebase across modules so attendees grow familiar.

### `sample-large-app/` (~30 files)
A larger Node.js service (REST API + workers + utils) with more files but lighter content per file. Designed so a "find every place that reads env vars" prompt has to touch many files — making the context-bloat problem visible. Used only by Module 5A.

---

## 7. Plugin: `security-quickscan` (Capstone)

Lives at `modules/06-capstone/sample-plugin/`. Composed of:

- `commands/quickscan.md` — slash command that runs a quick scan workflow
- `agents/vuln-finder.md` — a subagent specialized in flagging risky code
- `.claude/settings.json` — a hook that audit-logs commands + permission rules
- `CLAUDE.md` — primes the model with the plugin's own conventions
- `README.md` — installation steps

Attendees install it, run it, then inspect each file and answer "which primitive is this?" in `lab/plugin-anatomy.md`.

---

## 8. Slide Deck (`slides/claude-code-foundations.md`)

Single Marp markdown file. Sections mirror the modules. Per-section structure:
- Title + 1-line learning objective
- 2–3 concept slides with diagrams
- 1 "lab kickoff" slide with the lab task and acceptance criterion
- (Optional) 1 "anti-pattern" slide

Exported to PDF and committed alongside the source so non-Marp users can open it.

---

## 9. Open Items (instructor-resolved before delivery)

1. **Sunrise MCP install:** placeholders in Module 5B's "Replace with Sunrise MCP" section. Instructor fills in install command, endpoint, and auth before delivering the workshop. Public filesystem MCP is the working default.
2. **Pre-flight email template:** `PREFLIGHT.md` doubles as the template — instructor copies it into the calendar invite or sends as email.
3. **Auth posture during workshop:** assumes attendees use their own Claude Code subscriptions. If org provides a shared key, instructor adjusts PREFLIGHT.md.

---

## 10. Out of Scope

- Threat modeling (Workshop 2)
- AITM plugin specifics (Workshop 2)
- Authoring an MCP server from scratch
- Advanced agentic patterns (multi-agent orchestration, FSM design)
- IDE-specific integrations beyond a brief mention
- Web/desktop Claude Code clients (terminal only)
