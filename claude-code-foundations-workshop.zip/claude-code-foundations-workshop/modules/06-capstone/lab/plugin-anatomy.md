# Module 6 — Plugin Anatomy

For each file in `modules/06-capstone/sample-plugin/`, identify which primitive it represents and write 1 sentence describing what it contributes.

| File | Primitive | What it contributes |
|------|-----------|---------------------|
| `.claude-plugin/commands/quickscan.md` | | |
| `.claude-plugin/agents/vuln-finder.md` | | |
| `.claude-plugin/settings.json` (`permissions`) | | |
| `.claude-plugin/settings.json` (`hooks`) | | |
| `CLAUDE.md` | | |
| `README.md` | | |
