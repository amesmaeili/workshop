# security-quickscan plugin — context

This project has the `security-quickscan` plugin installed. When the `/quickscan` slash command runs:

- Always dispatch the `vuln-finder` subagent — do not do the scan inline. Keep the parent context clean.
- Save the report to `quickscan-report.md` in the project root. Overwrite it if it exists.
- Sort findings by severity (critical → high → medium → low).

## Categories the scan covers

- Hardcoded credentials (API keys, passwords, tokens)
- SQL injection (string concatenation into queries)
- Command injection (user input passed to `exec` / `spawn` / shell)
- Missing authorization (sensitive endpoints with no role check)
- Sensitive data in logs (passwords, tokens, PII)

## Out of scope

- Dependency CVE scanning (use `npm audit` for that)
- Secrets in git history (use `gitleaks` for that)
- Architectural threat modeling (that's the AITM plugin — Workshop 2)
