# `security-quickscan` — Capstone Plugin

A small Claude Code plugin that runs a quick security scan over a project. Used as the capstone in Module 6 — students install it, run it, and dissect it.

## What it does

Adds a single slash command, `/quickscan`, that:

1. Dispatches a `vuln-finder` subagent to scan the project
2. The subagent produces a structured report (file:line, category, severity, recommendation)
3. The report is saved to `quickscan-report.md` in the project root

## What's inside

```
sample-plugin/
├── README.md                      <- this file
├── CLAUDE.md                      <- primes the model on the plugin's conventions
└── .claude-plugin/
    ├── settings.json              <- permission rules + audit hook
    ├── commands/
    │   └── quickscan.md           <- the /quickscan slash command
    └── agents/
        └── vuln-finder.md         <- specialized scanning subagent
```

## Install

See the lab instructions in `modules/06-capstone/README.md`.

## Why this looks the way it does

It's a tiny, deliberate echo of the AITM threat-modeling plugin's structure — same primitives (slash command + subagent + permissions + hook + CLAUDE.md), much smaller. After Module 6, when you look at AITM, you should recognize the shape.
