# Module 6 — Capstone

**Time:** 25 min (5 min lecture + 20 min lab)
**Goal:** Install a real plugin, run it, and identify which primitive each piece uses.

---

## Concept Recap

A **plugin** is a packaged bundle of the primitives you've learned:

| Plugin file | Primitive |
|-------------|-----------|
| `commands/<name>.md` | Custom slash command (Module 4) |
| `agents/<name>.md` | Subagent (Module 5) |
| `settings.json` `permissions` | Permission rules (Module 2) |
| `settings.json` `hooks` | Hooks (Module 4) |
| `.mcp.json` | MCP server configuration (Module 5) |
| `CLAUDE.md` | Context priming (Module 3) |
| Knowledge files | Domain reference data (read by agents) |

Workshop 2's AITM plugin uses *all* of these at scale: ~11 subagents, multiple slash commands, hooks for state persistence, MCP integrations, and YAML knowledge files for OWASP frameworks. Today's capstone is much smaller — but it's the same shape.

---

## Lab — Install & Dissect `security-quickscan`

You'll install a small "security-quickscan" plugin into `sample-app/`, run its slash command, and then map each plugin file to the primitive it represents.

### Steps

1. **Install the plugin into `sample-app/`.** From the workshop root:

   ```bash
   cd sample-app
   cp -r ../modules/06-capstone/sample-plugin/.claude-plugin/* .claude/
   cp ../modules/06-capstone/sample-plugin/CLAUDE.md ./.claude-plugin-CLAUDE.md
   ```

   > **Note:** `sample-app/` already has a `.claude/settings.json` from Module 2. The plugin's settings will need to be merged. The simplest path for the lab: rename your Module 2 settings to `settings.module2.json` (so you don't lose it), then copy the plugin's `settings.json` into place. The plugin's settings include the same deny rules plus its own hook.

   Concrete commands:
   ```bash
   mv .claude/settings.json .claude/settings.module2.json
   cp ../modules/06-capstone/sample-plugin/.claude-plugin/settings.json .claude/settings.json
   ```

2. **Open Claude Code in `sample-app/`:**
   ```bash
   claude
   ```

3. **Verify the plugin loaded.** Type `/help` and look for `/quickscan` in the slash command list.

4. **Run the plugin:**
   ```
   /quickscan
   ```

   The plugin should:
   - Dispatch its `vuln-finder` subagent
   - Produce a markdown report of vulnerabilities in `sample-app/`
   - Save the report to `quickscan-report.md` in the project root

5. **Read the report.** Compare it to your Module 1 findings — does it overlap? Did it find anything new?

6. **Dissect the plugin.** Open `modules/06-capstone/sample-plugin/` in your editor and inspect every file. Then fill in `modules/06-capstone/lab/plugin-anatomy.md` — for each file, name the primitive it represents and write 1 sentence on what it contributes.

### Acceptance criteria

- The plugin installed and `/quickscan` runs successfully
- `sample-app/quickscan-report.md` exists with at least one finding
- `modules/06-capstone/lab/plugin-anatomy.md` is filled in for every plugin file

### Cleanup (optional)

To restore your Module 2 settings:
```bash
cd sample-app
mv .claude/settings.module2.json .claude/settings.json
```

### When you're done (or stuck for 5 min)

Open `answers/06-capstone/SOLUTION.md`.
