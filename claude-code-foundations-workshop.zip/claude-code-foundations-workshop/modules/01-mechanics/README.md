# Module 1 — Mechanics

**Time:** 18 min (7 min lecture + 10 min lab + 1 min wrap)
**Goal:** Understand the agentic loop and use Claude Code to read/search a codebase like a security reviewer.

---

## Concept Recap

Claude Code is *not* a chat box. It's an **agentic CLI** that runs a loop:

1. You give it a task.
2. Claude decides what tools to call: `Read`, `Grep`, `Glob`, `Bash`, `Edit`, `Write`.
3. The tools execute and return results.
4. Claude decides what to do next — call another tool, write a file, or answer you.
5. Loop until the task is done.

This means Claude can:
- Read your files (without you pasting them)
- Search across the repo with grep
- Edit files
- Run shell commands

And it does this **without you driving each step**. You hand it a goal; it does the work.

For security review, the killer features are **Grep** (find patterns) and **Read** (open specific files). You can ask high-level questions like *"are there hardcoded secrets in this codebase?"* and Claude figures out *how* to search.

### Anti-pattern

Don't paste code into Claude Code. It already has Read. Just point it at the file.

---

## Lab — Be a Security Reviewer

You'll explore `sample-app/` (the Internal Notes Service) and find unsafe patterns using Claude Code's tools.

### Steps

1. **Open a Claude session in `sample-app/`:**
   ```bash
   cd sample-app
   claude
   ```

2. **First prompt — let Claude orient itself:**
   ```
   List every place this app reads from the database. For each, tell me whether it looks safe or unsafe and why.
   ```
   Watch which tools it uses. You should see `Grep` and `Read` appear.

3. **Follow up — make it concrete:**
   ```
   Show me the unsafe ones with file paths and line numbers in this format:
   path/to/file.js:LINE — short reason
   ```

4. **Capture the result:**
   Copy Claude's final list (file:line — reason) into `modules/01-mechanics/lab/findings.md`.

5. **Bonus (if time):** ask one more question:
   ```
   Are there any other categories of security flaws in this app besides SQL injection?
   Search the code and give me a short list.
   ```

### Acceptance criterion

`modules/01-mechanics/lab/findings.md` exists and contains at least 3 file:line entries with short reasons. Flag any false positives or missed issues to your instructor — that's part of the learning.

### When you're done (or stuck for 5 min)

Open `answers/01-mechanics/SOLUTION.md`.
