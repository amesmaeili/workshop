# Module 1 Lab — Findings

Replace this content with the file:line entries Claude returns.

Format:

```
path/to/file.js:LINE — short reason
```

## Findings

(your entries here)
