# Module 4 — Extensibility

**Time:** 18 min (7 min lecture + 10 min lab + 1 min wrap)
**Goal:** Author a custom slash command and a hook. Understand how these primitives compose into plugins.

---

## Concept Recap

### Custom slash commands

A slash command is a **reusable prompt**. You save a markdown file with optional frontmatter and a body, and Claude exposes it as `/your-command`.

Location: `.claude/commands/<name>.md` (project) or `~/.claude/commands/<name>.md` (user).

Minimal example — `.claude/commands/secret-scan.md`:

```markdown
---
description: Scan the codebase for hardcoded secrets and produce a markdown report.
---

Search this codebase for common hardcoded-secret patterns:
- API keys (sk_, AKIA, AIza, ghp_, etc.)
- Passwords assigned to variables (password = "...", secret = "...")
- JWT secrets and signing keys
- Connection strings with embedded credentials

Output a markdown table with columns: file, line, pattern matched, redacted snippet.
End with a one-paragraph summary of the riskiest findings.
```

When you type `/secret-scan` in the REPL, Claude runs this prompt. You can pass arguments with `$ARGUMENTS`.

### Hooks

Hooks are **automated behaviors** that run on lifecycle events. The big ones:

| Event | Fires | Use case |
|-------|-------|----------|
| `PreToolUse` | Before any tool call | Audit, block, validate inputs |
| `PostToolUse` | After a tool call | Log results, transform output |
| `Stop` | When Claude finishes a turn | Run a check, notify |
| `UserPromptSubmit` | When you submit a prompt | Inject context, log prompts |

Hooks are configured in `settings.json` and are *shell commands* — they receive event data as JSON on stdin.

Minimal example — append a line to `settings.json`:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          { "type": "command", "command": "jq -r '.tool_input.command // empty' >> /tmp/audit.log" }
        ]
      }
    ]
  }
}
```

Now every Bash call appends the command to `/tmp/audit.log` *before* Claude runs it.

### How this connects to plugins

A plugin is just a packaged bundle of these primitives. The AITM threat-modeling plugin is:
- ~10 slash commands (or one big orchestrator)
- ~11 specialized subagents
- Hooks for state persistence
- Knowledge files
- An MCP integration

You're learning the bricks. The capstone in Module 6 walks you through a finished house.

---

## Lab — Automate a Security Check

You'll create both a custom slash command AND a hook in `sample-app/`.

### Steps

#### Part A — Custom slash command (5 min)

1. Make sure `sample-app/.claude/commands/` exists:
   ```bash
   mkdir -p sample-app/.claude/commands
   ```

2. Create `sample-app/.claude/commands/secret-scan.md` with frontmatter (`description`) and a prompt that:
   - Searches for hardcoded secret patterns (API keys, passwords in source, JWT secrets, AWS keys)
   - Outputs a markdown table: file, line, pattern, redacted snippet
   - Ends with a brief risk summary

3. Open Claude in `sample-app/` and run:
   ```
   /secret-scan
   ```

4. Save the report Claude returns to `modules/04-extensibility/lab/secret-scan-report.md`.

#### Part B — Audit hook (5 min)

1. Edit `sample-app/.claude/settings.json` (the file you wrote in Module 2). Add a `hooks` block that registers a `PreToolUse` hook on `Bash`:
   - Command: `jq -r '.tool_input.command // empty' >> /tmp/claude-audit.log`

2. In the same Claude session (or a new one), run a prompt that triggers a Bash call. Easy way:
   ```
   Run `ls -la` and tell me what's in this directory.
   ```

3. After Claude completes, check the audit log:
   ```bash
   cat /tmp/claude-audit.log
   ```
   You should see the Bash command(s) Claude attempted.

4. Copy the audit log contents into `modules/04-extensibility/lab/audit-log.txt`.

### Acceptance criteria

- `sample-app/.claude/commands/secret-scan.md` exists with frontmatter + body
- `sample-app/.claude/settings.json` has a `hooks.PreToolUse` entry
- `modules/04-extensibility/lab/secret-scan-report.md` contains Claude's scan output
- `modules/04-extensibility/lab/audit-log.txt` contains at least one logged command

### When you're done (or stuck for 5 min)

Open `answers/04-extensibility/SOLUTION.md`.
