# Module 2 Lab — Proof of Denied Operation

Paste the relevant terminal output here showing Claude attempting an `rm` command and the system blocking it.
