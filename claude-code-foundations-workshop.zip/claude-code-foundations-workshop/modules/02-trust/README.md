# Module 2 — Trust

**Time:** 18 min (7 min lecture + 10 min lab + 1 min wrap)
**Goal:** Understand Claude Code's permission model and lock down what it can do via `settings.json`.

---

## Concept Recap

### Why this matters for security folks

Claude Code can run shell commands. By default, dangerous commands prompt you ("Allow this Bash call? y/n"). That's fine for one session, but you don't want to make trust decisions one prompt at a time. You want **policy**.

`settings.json` is that policy.

### The permission model

Every tool call (Bash, Read, Edit, Write, plus tools added by plugins/MCPs) is checked against three lists:

| List | Behavior |
|------|----------|
| `permissions.allow` | Auto-allow without prompting |
| `permissions.ask` | Prompt the user (the default for unknown tools) |
| `permissions.deny` | Block outright, no prompt |

Rules can target a tool generally (`"Bash"`) or a specific invocation pattern (`"Bash(rm:*)"`, `"Bash(curl:*)"`).

### Settings hierarchy

| Scope | Path | When it applies |
|-------|------|----------------|
| **User** (global) | `~/.claude/settings.json` | All your projects |
| **Project** (shared) | `<project>/.claude/settings.json` | When you run Claude in this directory; commits to git |
| **Project** (local) | `<project>/.claude/settings.local.json` | Same, but gitignored — for personal overrides |

More-specific scopes override less-specific ones. The deny list **always wins**.

### Anti-pattern

Don't auto-allow `Bash` globally. You won't see what Claude does, and one bad prompt can wreck things. Auto-allow read-only tools (`Read`, `Grep`, `Glob`); leave Bash on `ask`.

---

## Lab — Lock It Down

You'll write a project-scoped `settings.json` for `sample-app/` that lets Claude read and search freely, but constrains what it can execute.

### Steps

1. Make sure you're in `sample-app/`:
   ```bash
   cd sample-app
   ```

2. Create `.claude/settings.json` with the following policy:
   - `Read`, `Grep`, `Glob` → auto-allow
   - `Bash` → ask (default — you don't need to list it)
   - `Bash(rm:*)` → deny
   - `Bash(curl:*)` → deny
   - `Write` and `Edit` → ask

   The file structure looks like:
   ```json
   {
     "permissions": {
       "allow": ["..."],
       "deny": ["..."]
     }
   }
   ```

3. Start a new Claude session in `sample-app/`:
   ```bash
   claude
   ```

4. **Verify allow:** ask Claude to grep something. It should run without prompting.
   ```
   Grep for "API_KEY" in this codebase and tell me what you find.
   ```

5. **Verify deny:** ask Claude to do something destructive.
   ```
   Delete the app.log file with rm.
   ```
   You should see Claude attempt the Bash call and the system *deny* it. Note: Claude may try alternate strategies — the point is `rm` itself was blocked.

6. **Capture proof:** copy the relevant terminal output (Claude's attempt + the denial message) into `modules/02-trust/lab/proof.md`.

### Acceptance criterion

- `sample-app/.claude/settings.json` exists with the rules above
- `modules/02-trust/lab/proof.md` shows a denied `rm` attempt

### When you're done (or stuck for 5 min)

Open `answers/02-trust/SOLUTION.md`.
