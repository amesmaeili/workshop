# Module 5 — Delegation

**Time:** 23 min (9 min lecture + 12 min lab + 2 min wrap)
**Goal:** Understand when to delegate to a subagent (and why subagents matter at scale), and how to install/use an MCP server.

---

## Concept Recap

### Two ways to extend Claude Code

| Primitive | What it adds | Lives where |
|-----------|--------------|-------------|
| **Subagent** | A *specialized agent* that gets its own context window | `.claude/agents/<name>.md` |
| **MCP server** | New *tools and data sources* Claude can call | `.mcp.json` or `settings.json` |

A subagent extends Claude with **agentic work delegation**. An MCP extends Claude with **tools and data**.

### Why subagents matter at scale

When the codebase is large, asking the main session to "find every place this app reads env vars and rate the risk" forces Claude to:

1. Grep across the repo
2. **Read each matching file into the parent context window**
3. Summarize across all of them

Step 2 is the killer. Reading 30 files into the parent thread fills context fast. Token costs go up. The model has to juggle all of it. Later turns are slower and worse-informed.

A subagent has its **own context**. You dispatch it with a task and a tool list; it does the work in isolation; it returns a *summary* to the parent. The parent thread stays clean.

```
        Without subagent                       With subagent
   ┌─────────────────────────┐         ┌─────────────────────────┐
   │ parent context          │         │ parent context          │
   │  - prompt               │         │  - prompt               │
   │  - read file 1          │         │  - dispatch subagent    │
   │  - read file 2          │         │  - subagent summary     │
   │  - read file 3          │         │                         │
   │  - ... (30 files)       │         │ ─────────────────       │
   │  - summary              │         │   subagent context      │
   └─────────────────────────┘         │  - reads 30 files       │
                                        │  - returns 1 summary    │
                                        └─────────────────────────┘
```

### When to use a subagent

- The task requires reading many files (Claude will Read them into parent context otherwise)
- The task is parallelizable (you can dispatch several subagents at once)
- The task needs specialized instructions you don't want polluting your main session

### What is a subagent file

`.claude/agents/<name>.md` — frontmatter declares the agent's identity, tools, and model; the body is its system prompt.

```markdown
---
name: env-auditor
description: Find every place env vars are read and rate the risk.
tools: Read, Grep, Glob
---

You are an env-var auditor. Your job is to find every place this codebase
reads from `process.env` and produce a structured table:

| file:line | env var name | risk | reason |

Risk is one of: low, medium, high. Mark high if the var is a secret with
no fallback, medium if it has a permissive fallback, low if it's a
non-sensitive config value.

Return ONLY the table and a one-paragraph summary. Do not return raw file
contents to the parent.
```

You invoke it via the `Agent` tool (Claude does this for you when you ask).

### MCP servers

MCP (Model Context Protocol) is the standard way to give Claude *external tools*. Examples:
- **filesystem** — read/write outside the project root
- **github** — open PRs, read issues, manage labels
- **postgres** — query a real database
- **your internal API** — wrap any HTTP API as MCP tools

Configured in `.mcp.json` (project) or `settings.json` (user). Each MCP server contributes tools named `mcp__<server>__<tool>`.

The AITM threat-modeling plugin uses two MCPs: **Sunrise** (internal app metadata) and **Jira** (ticket creation).

---

## Lab — Two Ways to Extend Claude

### Part A — Subagents at scale (6 min)

Goal: see the difference between asking the main thread vs delegating to a subagent on a sizeable codebase.

1. **The naive way (main thread).** Open a Claude session in `sample-large-app/`:
   ```bash
   cd sample-large-app
   claude
   ```

   Run:
   ```
   Find every place this app reads from process.env, list them with file:line and the env var name, and rate the risk of each (low/medium/high) based on whether it's a secret and whether there's a fallback.
   ```

   Watch how many `Read` calls Claude makes. Note the rough number.

2. **The clean way (subagent).** Exit the REPL. Copy the provided agent file into the project:
   ```bash
   mkdir -p .claude/agents
   cp ../modules/05-delegation/lab/agents/env-auditor.md .claude/agents/
   ```

   Start a fresh session:
   ```bash
   claude
   ```

   Run:
   ```
   Use the env-auditor subagent to find every place this app reads from process.env, with risk ratings.
   ```

   Watch the parent thread — Claude dispatches the subagent and gets back a summary. The parent doesn't fill with raw file contents.

3. **Compare.** In `modules/05-delegation/lab/comparison.md`, fill in:
   - **Main thread:** approximate number of `Read` calls you saw
   - **Subagent:** how the parent context looked — was it filled with file contents, or just a summary?
   - **Your takeaway:** in what situations would you reach for a subagent first?

### Part B — Install an MCP server (6 min)

We'll install the **filesystem MCP** — a public, official MCP that lets Claude read/write outside its project root. This works out of the box; no auth.

> **For instructors:** if your org uses the Sunrise MCP, see the **"Replace with Sunrise MCP"** template at the bottom of this file. Swap in your install command before delivering the workshop.

1. **Configure the MCP.** In `sample-large-app/`, create or edit `.mcp.json`:

   ```json
   {
     "mcpServers": {
       "filesystem": {
         "command": "npx",
         "args": [
           "-y",
           "@modelcontextprotocol/server-filesystem",
           "/tmp"
         ]
       }
     }
   }
   ```

   This grants the MCP read/write access to `/tmp` only.

2. **Restart Claude Code.** Exit any running session and re-open in `sample-large-app/`.

3. **Verify the MCP loaded:**
   ```
   /mcp
   ```
   You should see `filesystem` listed as connected, with several tools (`mcp__filesystem__read_file`, etc.).

4. **Use it.** Ask Claude to do something via the MCP:
   ```
   Use the filesystem MCP to write a file at /tmp/mcp-hello.txt with the text "MCP works".
   Then read it back and confirm.
   ```

   Verify Claude uses `mcp__filesystem__write_file` and `mcp__filesystem__read_file` tools (not Bash).

5. **Capture proof:** screenshot or copy the `/mcp` output and the tool calls into `modules/05-delegation/lab/mcp-proof.md`.

### Acceptance criteria

- `modules/05-delegation/lab/comparison.md` filled in with subagent vs main-thread comparison
- `sample-large-app/.mcp.json` exists with the filesystem MCP
- `modules/05-delegation/lab/mcp-proof.md` shows `/mcp` output and at least one `mcp__filesystem__*` tool call

### When you're done (or stuck for 5 min)

Open `answers/05-delegation/SOLUTION.md`.

---

## "Replace with Sunrise MCP" — Instructor Template

> **For workshop instructors only.** This section is a placeholder for your org's internal **Sunrise MCP**. Swap in real values before delivering Module 5B if you want students to install Sunrise instead of (or in addition to) the public filesystem MCP. Keep the filesystem MCP version available as a fallback in case Sunrise auth has issues during the workshop.

**Things to fill in:**

```json
{
  "mcpServers": {
    "sunrise": {
      "command": "<COMMAND>",            // e.g., "npx" or absolute path to binary
      "args": [
        "<ARG1>",                        // e.g., "-y"
        "<PACKAGE-OR-ENTRYPOINT>",       // e.g., "@yourorg/sunrise-mcp"
        "<MAYBE-A-SUBCOMMAND>"           // e.g., "serve"
      ],
      "env": {
        "SUNRISE_API_URL": "<URL>",
        "SUNRISE_AUTH_TOKEN": "<TOKEN-OR-OAUTH-FLOW-ENV>"
      }
    }
  }
}
```

**Verification prompt to give students:**

```
What's the metadata for app `<SAMPLE-APP-ID-IN-SUNRISE>`?
```

Verify Claude uses `mcp__sunrise__*` tools and returns metadata.

**Pre-workshop checklist for the instructor:**

- [ ] Sunrise auth works for every attendee (test with one volunteer in advance)
- [ ] Pick a sample app ID that everyone can read
- [ ] Confirm the install command works on macOS / Linux / WSL
- [ ] Update `PREFLIGHT.md` with any Sunrise-specific install steps
