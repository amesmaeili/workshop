# Module 5A — Comparison: Main Thread vs Subagent

## Main thread

- Approximate number of `Read` calls observed: ___
- Did the parent context fill with file contents? (yes / no)
- Approximate length of the final answer: ___ lines

## Subagent

- Did the parent context fill with file contents? (yes / no)
- What did the parent receive back? (raw files / a summary / something else)
- Approximate length of the final answer: ___ lines

## Takeaway

In what kinds of tasks would you reach for a subagent first? Two sentences.
