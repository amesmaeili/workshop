# Module 0 — Driving the REPL: Cheatsheet

The universal in-REPL controls. Run any of these from inside `claude`.

> Module 0 is a **live-along** — there's no graded lab. This file is your reference for the rest of the workshop and after.

---

## Discoverability & exit

| Command | What it does |
|---------|--------------|
| `/help` | List every available slash command. Skim it once; you don't need to memorize. |
| `/status` | Show the current model, working directory, and session state. |
| `/exit` | Leave the REPL cleanly. `Ctrl-D` (EOF) and `Ctrl-C` twice also work. |

---

## Conversation hygiene

| Command | What it does |
|---------|--------------|
| `/clear` | Wipe the conversation. Start fresh. Use this between unrelated tasks. |
| `/compact` | Summarize the conversation so far and keep going. Use when context is full but the work isn't. |

**Rule of thumb:** new task → `/clear`. Same task, running long → `/compact`.

---

## Model & cost

| Command | What it does |
|---------|--------------|
| `/model` | Switch between Opus, Sonnet, and Haiku. Faster/cheaper vs. more capable. |
| `/cost` | Show what this session has cost so far. Security teams care; check it. |

---

## Input shortcuts (not slash commands, but you'll use them constantly)

| Shortcut | What it does |
|----------|--------------|
| `@path/to/file` | Reference a file in your prompt. Claude reads it without you pasting. Tab-completes. |
| `!command` | Escape to a shell command without leaving the REPL. Output stays in the conversation. |

Example:
```
> @sample-app/README.md what does this app do?
> !ls sample-app/routes/
```

---

## Covered later in the workshop

These commands exist; you'll learn each one in its own module.

| Command | Module |
|---------|--------|
| `/permissions` | Module 2 — Trust |
| `/init`, `#memory` | Module 3 — Context |
| `/agents` | Module 5 — Delegation |
| `/mcp` | Module 5 — Delegation |
| `/plugin` | Module 6 — Capstone |
