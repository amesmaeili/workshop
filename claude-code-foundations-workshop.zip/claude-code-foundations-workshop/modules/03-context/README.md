# Module 3 — Context

**Time:** 18 min (7 min lecture + 10 min lab + 1 min wrap)
**Goal:** Understand what Claude "sees" and use `CLAUDE.md` to prime the model on a codebase's conventions.

---

## Concept Recap

### What Claude sees

When you start a Claude Code session, the model gets:

1. A system prompt (Claude Code's own — you don't write this)
2. Your **CLAUDE.md** files, in order: user → project → subdir
3. Your prompt
4. Tool results as the loop runs

You control 2 and 3. The biggest lever is `CLAUDE.md`.

### CLAUDE.md hierarchy

| Path | Scope |
|------|-------|
| `~/.claude/CLAUDE.md` | All your sessions (preferences, your role) |
| `<project>/CLAUDE.md` | Anyone working in this project (conventions, where things live, what NOT to touch) |
| `<project>/<subdir>/CLAUDE.md` | Subset of the project (e.g., a package with its own rules) |

Lower-level files **add to** higher-level ones. They don't override.

### What goes in a project CLAUDE.md

Aim for things Claude *can't infer from one quick look* at the code:

- Tech stack and architectural style ("This is an Express + SQLite service. Auth uses cookies, not JWT.")
- Where things live ("Routes are in `src/routes/`. Auth logic is split between `routes/auth.js` and `middleware/`.")
- Security/coding conventions to enforce ("All SQL must use parameterized queries. Never concatenate strings into SQL.")
- What NOT to touch ("Don't modify `src/db/migrations.js` without coordinating — it's run on startup.")
- Test commands, lint commands, useful scripts

### Anti-patterns

- Kitchen-sink CLAUDE.md (200 lines of everything you ever thought) — Claude reads it all every turn. Be tight.
- Stuff Claude can derive from one Read (`"this is a Node.js project"`) — wasted tokens.
- Stuff that changes weekly — it'll go stale. Use commit messages or tickets for that.

---

## Lab — Prime the Model

You'll write a `CLAUDE.md` for `sample-app/` and observe how it changes Claude's behavior on a fresh task.

### Steps

1. **First, get the baseline.** A pre-recorded "no-CLAUDE.md" transcript is in `modules/03-context/lab/baseline-transcript.md`. Read it. This is what happens when you ask Claude to add input validation to the signup endpoint *without* a CLAUDE.md.

2. **Now write your CLAUDE.md.** In `sample-app/CLAUDE.md`, document at minimum:
   - Stack (Node.js, Express, SQLite via better-sqlite3, bcryptjs)
   - Where routes live (`src/routes/`)
   - At least 3 security conventions you want Claude to enforce — pick from the issues you found in Module 1 (e.g., "All SQL must use parameterized queries — no string concatenation")
   - One "do not touch" entry of your choice

3. **Start a fresh Claude session in `sample-app/`** (exit any open session first to load the new CLAUDE.md):
   ```bash
   claude
   ```

4. **Run the same prompt as the baseline:**
   ```
   Add input validation to the signup endpoint in src/routes/auth.js.
   ```

5. **Compare.** Does Claude reference any of the conventions you wrote? Does it use parameterized queries? Does it stay in `src/routes/auth.js` or wander into `migrations.js`?

6. **Write up your observation** in `modules/03-context/lab/observation.md` (2-3 sentences):
   - Did the CLAUDE.md change Claude's approach? How?
   - What did Claude reference from your CLAUDE.md?

### Acceptance criterion

- `sample-app/CLAUDE.md` exists with stack, locations, ≥3 security conventions, ≥1 "do not touch"
- `modules/03-context/lab/observation.md` has your 2-3-sentence comparison

### When you're done (or stuck for 5 min)

Open `answers/03-context/SOLUTION.md`.
