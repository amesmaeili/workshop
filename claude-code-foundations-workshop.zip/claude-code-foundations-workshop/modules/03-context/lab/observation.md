# Module 3 Lab — Observation

Compare Claude's behavior with vs without your CLAUDE.md. 2-3 sentences.

- Did the CLAUDE.md change Claude's approach?
- What did it reference from your CLAUDE.md?
- Did it catch any of the surrounding security flaws?
