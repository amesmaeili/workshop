# Baseline Transcript — No CLAUDE.md

This is what happens when you run the prompt below in `sample-app/` *without* a `CLAUDE.md`. Use it as your "before" baseline for Module 3's lab.

---

## Prompt

```
Add input validation to the signup endpoint in src/routes/auth.js.
```

## Claude's behavior (summary)

> *Reads `src/routes/auth.js`*
>
> Looking at the signup handler... I'll add basic validation: check that email and password are present, validate email format with a regex, and require password length ≥ 8.
>
> *Edits `src/routes/auth.js`* — wraps the existing handler in a validation block:
>
> ```js
> router.post('/signup', (req, res) => {
>   const { email, password } = req.body;
>   if (!email || !password) return res.status(400).json({ error: 'missing fields' });
>   if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'invalid email' });
>   if (password.length < 8) return res.status(400).json({ error: 'password too short' });
>   const hash = bcrypt.hashSync(password, 10);
>   const sql = `INSERT INTO users (email, password_hash) VALUES ('${email}', '${hash}')`;
>   try {
>     db.exec(sql);
>     log(`signup ok email=${email} password=${password}`);
>     res.json({ ok: true });
>   } catch (err) {
>     res.status(400).json({ error: err.message });
>   }
> });
> ```
>
> Done — added presence, format, and length validation.

## Observations

- Added presence/format/length checks ✓
- **Left the SQL string concatenation in place** (still vulnerable to injection)
- **Left the password being logged in plaintext** in place
- Did not flag any of the security issues that *should* have been caught

This is the exact problem CLAUDE.md fixes: Claude doesn't know your security conventions unless you tell it. It optimizes for the literal task and leaves the surrounding flaws alone.
