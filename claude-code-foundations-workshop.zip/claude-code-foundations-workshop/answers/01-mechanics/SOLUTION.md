# Module 1 — Solution

## Expected `findings.md` contents

The `sample-app/` codebase has at least these unsafe DB reads. Your list should look something like:

```
src/routes/auth.js:14 — SQL injection: email/hash concatenated into INSERT via template literal
src/routes/auth.js:26 — SQL injection: email concatenated into SELECT via template literal
src/routes/notes.js:18-21 — SQL injection: userId AND filter concatenated into SELECT
```

Bonus follow-up — other categories Claude should surface:

```
src/routes/auth.js:18 — sensitive-data-in-logs: password logged in plaintext
src/routes/notes.js:36 — missing-authz: DELETE has no ownership check
src/routes/admin.js:7 — hardcoded-credential: ADMIN_API_KEY embedded in source
src/routes/admin.js:21 — command-injection: req.body.filename interpolated into shell command
src/utils/shell.js:4-7 — runShell wraps exec with no escaping
server.js:9 — hardcoded-credential: SESSION_SECRET hardcoded
```

## What "good" looks like

- Student used Claude (didn't grep the files themselves) — confirmed by their description of which tools fired (Grep, Read).
- Findings include file:line, not just file names.
- At least one false-positive flagged or missed issue is OK to discuss — the lab is about using Claude's tooling, not getting 100% recall.

## Common stumbles

- **"Claude didn't return line numbers."** Push back with the explicit format request: *"Show me file:line"*. Claude usually complies.
- **"Claude over-claims."** Sometimes Claude flags things that aren't really vulnerable (e.g., the bcrypt call as "weak crypto"). Use this as a teaching moment — Claude is a force multiplier, not an oracle. You still review.

## Reference: the canonical findings file

See `solution-files/findings.md` in this directory for a model answer.
