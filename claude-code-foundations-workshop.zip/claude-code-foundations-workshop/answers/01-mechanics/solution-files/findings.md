# Module 1 Lab — Findings (Reference Answer)

## Unsafe DB reads (from the lab's primary prompt)

```
src/routes/auth.js:14 — SQL injection: ${email} and ${hash} concatenated into INSERT
src/routes/auth.js:26 — SQL injection: ${email} concatenated into SELECT WHERE clause
src/routes/notes.js:18-21 — SQL injection: ${userId} (sourced from cookie session, OK) AND ${filter} (from user-controlled query string, NOT OK) concatenated
```

## Other categories (from the bonus prompt)

```
server.js:9                  — hardcoded-credential: SESSION_SECRET as a string literal
src/routes/auth.js:18,40     — sensitive-data-in-logs: password and email logged together at signup; user_id+email at login
src/routes/admin.js:7        — hardcoded-credential: ADMIN_API_KEY string literal
src/routes/admin.js:11       — missing-authz: only checks the static key — no role check, anyone with the leaked key is admin
src/routes/admin.js:21       — command-injection: req.body.filename interpolated into a shell command via runShell
src/routes/notes.js:36       — missing-authz: DELETE deletes by id with no ownership check (any authed user can delete any note)
src/utils/shell.js:4-7       — wrapper around child_process.exec with no escaping (root cause for the command-injection finding)
```
