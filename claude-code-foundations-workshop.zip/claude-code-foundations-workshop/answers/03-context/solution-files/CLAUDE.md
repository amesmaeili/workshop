# Internal Notes Service — context for Claude

## Stack

Node.js + Express. SQLite via `better-sqlite3`. Passwords hashed with `bcryptjs`. Sessions are cookie-based and stored in a `sessions` table.

## Layout

- `server.js` — entry point, mounts route modules
- `src/routes/` — route handlers (`auth.js`, `notes.js`, `admin.js`)
- `src/db/` — SQLite connection + migrations
- `src/utils/` — `logger.js`, `shell.js`

## Security conventions you must enforce

- **All SQL must be parameterized.** Use `db.prepare(...).get(...)` / `.run(...)` / `.all(...)` with placeholders. Never build SQL with string concatenation or template literals.
- **Never log credentials.** Don't include `password`, session tokens, API keys, or full request bodies of auth endpoints in `log()` calls.
- **Every user-scoped DELETE/UPDATE must check ownership.** Compare `user_id` from the session against the row's `user_id` before mutating.

## What NOT to touch

- `src/db/migrations.js` — runs on every startup. Modifying schema requires coordination.
- `server.js` `SESSION_SECRET` — there's a known issue (it's hardcoded). Rotation is being planned separately. Don't silently change it.
