# Module 3 — Solution

## Expected `sample-app/CLAUDE.md`

A solid CLAUDE.md for this project covers stack, layout, conventions, and what not to touch. See `solution-files/CLAUDE.md` for a model. The reference version is below — yours can differ in wording, but should hit similar beats.

```markdown
# Internal Notes Service — context for Claude

## Stack

Node.js + Express. SQLite via `better-sqlite3`. Passwords hashed with `bcryptjs`. Sessions are cookie-based and stored in a `sessions` table.

## Layout

- `server.js` — entry point, mounts route modules
- `src/routes/` — route handlers (`auth.js`, `notes.js`, `admin.js`)
- `src/db/` — SQLite connection + migrations
- `src/utils/` — `logger.js`, `shell.js`

## Security conventions you must enforce

- **All SQL must be parameterized.** Use `db.prepare(...).get(...)` / `.run(...)` / `.all(...)` with placeholders. Never build SQL with string concatenation or template literals.
- **Never log credentials.** Don't include `password`, session tokens, API keys, or full request bodies of auth endpoints in `log()` calls.
- **Every user-scoped DELETE/UPDATE must check ownership.** Compare `user_id` from the session against the row's `user_id` before mutating.

## What NOT to touch

- `src/db/migrations.js` — runs on every startup. Modifying schema requires coordination.
- `server.js` `SESSION_SECRET` — there's a known issue (it's hardcoded). Rotation is being planned separately. Don't silently change it.
```

## Expected behavior change

With the CLAUDE.md above, when you re-run `Add input validation to the signup endpoint`, Claude should:

- Add presence + format + length validation (same as baseline).
- Replace the SQL string concatenation with `db.prepare('INSERT INTO users (email, password_hash) VALUES (?, ?)').run(email, hash)` — because the convention says so.
- Remove `password=${password}` from the log line — because the convention says don't log credentials.

If Claude only adds validation and leaves the SQL or the log issue in place, the CLAUDE.md isn't doing its job. Things to check:

- Is the convention specific enough? "Use parameterized queries" is better than "write secure code."
- Does the CLAUDE.md actually live at `sample-app/CLAUDE.md` (not `sample-app/.claude/CLAUDE.md`)?
- Was a fresh session started after writing it?

## Common stumbles

- **"My CLAUDE.md is too long."** Trim. Anything Claude can derive from one Read doesn't need to be there.
- **"Claude ignored my conventions."** Make them imperative: "you must" / "always" / "never". Vague advice gets vague compliance.
- **"My observation is just 'it worked.'"** Push for specifics: which convention did Claude reference? What changed in the diff?

## What goes in `lab/observation.md`

A solid observation:

> *"With CLAUDE.md, Claude switched the signup INSERT to a parameterized prepared statement and dropped the password from the log call. It explicitly cited the parameterized-queries convention. Without CLAUDE.md, both flaws were left intact even though the validation was added correctly."*
