# Module 5 — Solution

## Part A — Subagent vs main thread

### What the main thread does

When you run the prompt without a subagent, Claude:

1. Greps for `process.env` — finds many hits across `src/config/*`, `src/db/*`, `src/middleware/*`, `src/services/*`, `src/workers/*`, `src/jobs/*`, `server.js`, `worker.js`.
2. Reads each file (or large chunks of each) into the **parent context**.
3. Builds the table.

You should observe roughly **15-25 Read calls** in the parent thread, and the parent's context window fills with chunks of source code from across the repo.

### What the subagent does

When you dispatch the `env-auditor`:

1. Claude calls the `Agent` tool with the env-auditor prompt and the same task.
2. The subagent does its grepping and reading **in its own context**.
3. The subagent returns a single structured table + one paragraph of summary.
4. The parent thread sees only that summary — no raw file contents.

You should observe **1 Agent call** in the parent and a clean response.

### Reference comparison

```markdown
## Main thread

- Approximate number of `Read` calls observed: 18 (varies; usually 15-25)
- Did the parent context fill with file contents? yes
- Approximate length of the final answer: 30-50 lines

## Subagent

- Did the parent context fill with file contents? no
- What did the parent receive back? a table + summary paragraph
- Approximate length of the final answer: 30-50 lines (similar output, but parent context is clean)

## Takeaway

Subagents are the right call when the task requires reading many files
and you only need the *result*, not the raw content. They keep the parent
context focused for follow-up work.
```

### Expected high/medium/low ratings

The env-auditor should rate, roughly:

- **high:** `JWT_SECRET` (with a hardcoded fallback), `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`, `INTERNAL_API_KEY`, `AWS_SECRET_ACCESS_KEY`, `SENDGRID_API_KEY`, `PAGER_DUTY_KEY`, `DB_PASSWORD`, `REDIS_PASSWORD`, `SLACK_WEBHOOK_URL`
- **medium:** parsed numerics (`parseInt(process.env.X || '...', 10)`) where bad input could throw or silently use a default; permissive booleans; the `ADMIN_EMAILS` split which silently filters bad input
- **low:** `PORT`, `LOG_LEVEL`, `SERVICE_NAME`, `DEFAULT_CURRENCY`, hosts/ports for known services, retention days

If a student's subagent only finds a few high-risk items, that's still acceptable — the *point* is the delegation, not 100% recall.

## Part B — MCP install

### Expected `.mcp.json`

```json
{
  "mcpServers": {
    "filesystem": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/server-filesystem",
        "/tmp"
      ]
    }
  }
}
```

### Expected `/mcp` output

```
filesystem    connected    (12 tools)
```

(Tool count varies by version — but it should be connected.)

### Expected tool calls

When you ask Claude to write `/tmp/mcp-hello.txt` and read it back, the trace should show:

```
mcp__filesystem__write_file({ path: "/tmp/mcp-hello.txt", content: "MCP works" })
mcp__filesystem__read_file({ path: "/tmp/mcp-hello.txt" })
```

NOT `Bash` calls. If Claude uses Bash instead, it didn't see the MCP — debug with `/mcp` first.

## Common stumbles

### Subagent half

- **"The subagent file didn't load."** Confirm it's at `sample-large-app/.claude/agents/env-auditor.md` and the frontmatter has `name:` and `tools:` keys. Restart the session.
- **"Claude did the work in the parent anyway."** Be explicit: *"Use the env-auditor subagent..."* If it still inlines, check that the agent's `description` field is clear about when it should fire.
- **"The subagent returned raw file contents."** That's a prompt-engineering issue in the subagent itself. The provided env-auditor.md says "Do NOT return raw file contents" — verify that line is present.

### MCP half

- **"npx fails with permissions or timeout."** Some networks block npm registry or take a while on first install. Pre-warm by running `npx -y @modelcontextprotocol/server-filesystem /tmp` in a regular terminal once before workshop.
- **"`/mcp` shows filesystem as failed."** Check that `npx` is in PATH. Check Node version (>= 18). Try the explicit-path form: `"command": "/usr/local/bin/node"`, `"args": ["./node_modules/..."]` if needed.
- **"MCP works for read but not write."** The args determine which directories are accessible. The example above grants `/tmp` only — writes to project root would fail (which is the point — least privilege).

## How this connects to the capstone

Module 6's plugin uses the *subagent* primitive (vuln-finder) but ships its own and doesn't require an MCP — keeping the capstone focused on plugin-anatomy rather than MCP wiring. In Workshop 2, AITM uses both subagents and MCPs heavily.
