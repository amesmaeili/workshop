# Module 4 — Solution

## Expected slash command

`sample-app/.claude/commands/secret-scan.md`:

```markdown
---
description: Scan the codebase for hardcoded secrets and produce a markdown report.
---

Search this codebase for common hardcoded-secret patterns:

- API keys (sk_, AKIA, AIza, ghp_, GH_TOKEN, etc.)
- Passwords assigned to variables (`password = "..."`, `secret = "..."`)
- JWT secrets and signing keys
- Connection strings with embedded credentials
- AWS access keys (AKIA[A-Z0-9]+)

For each match, output a markdown table row with:
- file
- line
- pattern category
- a redacted snippet (mask middle characters)

End with a one-paragraph summary of the riskiest findings.
```

See `solution-files/secret-scan.md` for the canonical version.

## Expected hook

In `sample-app/.claude/settings.json`, the file should now contain both your Module 2 permissions AND a hooks block:

```json
{
  "permissions": {
    "allow": ["Read", "Grep", "Glob"],
    "deny": ["Bash(rm:*)", "Bash(curl:*)"]
  },
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "jq -r '.tool_input.command // empty' >> /tmp/claude-audit.log"
          }
        ]
      }
    ]
  }
}
```

See `solution-files/settings.json` for the canonical version.

## What students should observe

- After running `/secret-scan`, Claude should find at least:
  - `src/routes/admin.js` — `ADMIN_API_KEY = 'sk_admin_...'`
  - `server.js` — `SESSION_SECRET = 'dev-secret-...'`
- After running a Bash command (e.g., `ls -la`), `/tmp/claude-audit.log` should contain that command.

## Common stumbles

- **"`/secret-scan` doesn't show up in `/help`."** Confirm the file is at `.claude/commands/secret-scan.md` (not `.claude/command/...` or wrong subdir). Restart the session.
- **"Hook didn't fire."** Most likely the JSON syntax broke the whole settings file — Claude silently falls back to no policy. Validate with `jq . settings.json`.
- **"jq is not installed."** macOS usually has it; Linux often doesn't. Tell students to swap the hook command for one that doesn't need jq:
  ```
  "command": "echo \"$CLAUDE_TOOL_INPUT\" >> /tmp/claude-audit.log"
  ```
  (Note: the exact env var name depends on the harness version. Check `claude --help` or docs if `$CLAUDE_TOOL_INPUT` doesn't work.)
- **"The hook blocked Claude entirely."** PreToolUse hooks that exit non-zero block the tool. The lab's `jq` command shouldn't ever fail, but if it does (missing jq), the Bash call may be blocked. The fallback above avoids this.

## How this connects to the next modules

You just hand-wrote: a slash command + a hook + permission rules — three of the five plugin primitives. Module 5 adds subagents and MCP. Module 6 ships you a plugin that bundles all of them.
