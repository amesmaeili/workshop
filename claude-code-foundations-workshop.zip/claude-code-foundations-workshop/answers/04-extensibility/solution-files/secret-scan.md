---
description: Scan the codebase for hardcoded secrets and produce a markdown report.
---

Search this codebase for common hardcoded-secret patterns:

- API keys (sk_, AKIA, AIza, ghp_, GH_TOKEN, etc.)
- Passwords assigned to variables (`password = "..."`, `secret = "..."`)
- JWT secrets and signing keys
- Connection strings with embedded credentials
- AWS access keys (AKIA[A-Z0-9]+)

For each match, output a markdown table row with:
- file
- line
- pattern category
- a redacted snippet (mask middle characters)

End with a one-paragraph summary of the riskiest findings.
