# Module 2 — Solution

## Expected `.claude/settings.json`

A correct file looks like this. See `solution-files/settings.json` for the canonical version.

```json
{
  "permissions": {
    "allow": [
      "Read",
      "Grep",
      "Glob"
    ],
    "deny": [
      "Bash(rm:*)",
      "Bash(curl:*)"
    ]
  }
}
```

## Notes on what this does

- `allow` auto-permits read-only tools so Claude can browse without prompting.
- `Bash` is **not** in either list — it falls through to the default `ask` behavior.
- `Bash(rm:*)` and `Bash(curl:*)` are blocked outright; even if you typed "yes" to a prompt, they'd be denied.
- `Write` and `Edit` are not in `allow` either — they'll prompt every time.

## What the denied-rm proof should look like

When you ask Claude to "delete the logs folder," it'll typically:

1. Decide it needs `Bash` to run `rm -rf logs` (or similar).
2. Attempt the call.
3. The system intercepts and shows a denial message — something like:

   ```
   The user has denied use of Bash(rm:*).
   ```

4. Claude either gives up or tries an alternate approach (e.g., empty the folder via Node, or ask you).

The key teaching point: Claude **does not get to retry-around** a deny rule. The deny is enforced by the harness, not by Claude's politeness.

## Common stumbles

- **"My settings.json isn't being read."** Verify the file is at `sample-app/.claude/settings.json`, not `sample-app/.claude.json` or similar. Restart the Claude session.
- **"Claude ran rm anyway."** Check JSON syntax (trailing commas, quotes). The settings parse silently — typos = no policy.
- **"My deny rule lets `rm -rf` through but blocks `rm file.txt`."** The pattern `Bash(rm:*)` should match either. If it doesn't, double-check there's no leading space in the rule string.

## How this connects to the next modules

You wrote `.claude/settings.json` here. In Module 4 you'll add a `hooks` block to the same file. In Module 6 the capstone plugin ships its own `settings.json` — you'll see how plugins layer on top of these primitives.
