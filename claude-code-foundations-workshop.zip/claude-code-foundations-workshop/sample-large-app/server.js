const express = require('express');
const ordersApi = require('./src/api/orders');
const customersApi = require('./src/api/customers');
const refundsApi = require('./src/api/refunds');
const webhooksApi = require('./src/api/webhooks');
const adminApi = require('./src/api/admin');
const authMiddleware = require('./src/middleware/auth');
const requestLogger = require('./src/middleware/request-logger');
const { logger } = require('./src/utils/logger');

const PORT = process.env.PORT || 8080;

const app = express();
app.use(express.json({ limit: process.env.MAX_REQUEST_SIZE || '1mb' }));
app.use(requestLogger);
app.use('/api/orders', authMiddleware, ordersApi);
app.use('/api/customers', authMiddleware, customersApi);
app.use('/api/refunds', authMiddleware, refundsApi);
app.use('/webhooks', webhooksApi);
app.use('/admin', adminApi);

app.listen(PORT, () => logger.info(`api listening on :${PORT}`));
