const { startOrderWorker } = require('./src/workers/order-worker');
const { startEmailWorker } = require('./src/workers/email-worker');
const { startPaymentWorker } = require('./src/workers/payment-worker');
const { startReconcileWorker } = require('./src/workers/reconcile-worker');
const { logger } = require('./src/utils/logger');

const WORKER_CONCURRENCY = parseInt(process.env.WORKER_CONCURRENCY || '4', 10);

logger.info(`starting workers concurrency=${WORKER_CONCURRENCY}`);
startOrderWorker(WORKER_CONCURRENCY);
startEmailWorker(WORKER_CONCURRENCY);
startPaymentWorker(WORKER_CONCURRENCY);
startReconcileWorker(WORKER_CONCURRENCY);
