# `sample-large-app` — Order Processing Service

A medium-sized Node.js service for an internal order-processing pipeline. Used in **Module 5** to demonstrate why subagents matter at scale.

> Many files. Many env-var reads scattered across them. The whole point: when you ask Claude in the main session to "find every place this app reads env vars and rate the risk," it has to read a lot of files — context fills up fast. Module 5's lab compares this with the same task delegated to a subagent.

## Stack

- Node.js + Express (API)
- Background workers (queue consumers)
- PostgreSQL + Redis
- Various third-party SDKs (mocked / declared only)

## Layout

```
sample-large-app/
├── package.json
├── server.js
├── worker.js
└── src/
    ├── api/             # HTTP routes
    ├── workers/         # background queue consumers
    ├── services/        # business logic
    ├── db/              # database connections
    ├── config/          # config loaders (lots of env reads)
    ├── middleware/      # express middleware
    ├── jobs/            # scheduled jobs
    └── utils/           # shared utilities
```

## You won't run it

This codebase exists to be *read*, not executed.
