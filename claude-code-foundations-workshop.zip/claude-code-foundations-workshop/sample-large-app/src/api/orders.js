const express = require('express');
const orderService = require('../services/order-service');

const router = express.Router();

router.post('/', async (req, res) => {
  const order = await orderService.create(req.user, req.body);
  res.json(order);
});

router.get('/:id', async (req, res) => {
  const order = await orderService.findById(req.params.id, req.user);
  if (!order) return res.status(404).json({ error: 'not found' });
  res.json(order);
});

router.post('/:id/cancel', async (req, res) => {
  const result = await orderService.cancel(req.params.id, req.user);
  res.json(result);
});

module.exports = router;
