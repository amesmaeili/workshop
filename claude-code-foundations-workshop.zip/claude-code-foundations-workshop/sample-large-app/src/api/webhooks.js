const express = require('express');
const stripeConfig = require('../config/stripe');
const webhookService = require('../services/webhook-service');

const router = express.Router();

router.post('/stripe', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const result = await webhookService.handleStripe(req.body, sig, stripeConfig.webhookSecret);
  res.json(result);
});

router.post('/internal/:source', async (req, res) => {
  const allowed = (process.env.INTERNAL_WEBHOOK_SOURCES || '').split(',');
  if (!allowed.includes(req.params.source)) return res.status(403).json({ error: 'forbidden' });
  const result = await webhookService.handleInternal(req.params.source, req.body);
  res.json(result);
});

module.exports = router;
