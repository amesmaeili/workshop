const express = require('express');
const customerService = require('../services/customer-service');

const router = express.Router();

router.get('/:id', async (req, res) => {
  const c = await customerService.findById(req.params.id);
  if (!c) return res.status(404).json({ error: 'not found' });
  res.json(c);
});

router.post('/', async (req, res) => {
  const c = await customerService.create(req.body);
  res.json(c);
});

module.exports = router;
