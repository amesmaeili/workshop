const express = require('express');
const refundService = require('../services/refund-service');

const router = express.Router();

router.post('/', async (req, res) => {
  const refund = await refundService.create(req.user, req.body);
  res.json(refund);
});

router.get('/:id', async (req, res) => {
  const refund = await refundService.findById(req.params.id);
  if (!refund) return res.status(404).json({ error: 'not found' });
  res.json(refund);
});

module.exports = router;
