const express = require('express');
const authConfig = require('../config/auth');
const orderService = require('../services/order-service');

const router = express.Router();

function requireInternalKey(req, res, next) {
  if (req.headers['x-internal-key'] !== authConfig.internalApiKey) {
    return res.status(403).json({ error: 'forbidden' });
  }
  next();
}

router.get('/stats', requireInternalKey, async (req, res) => {
  res.json(await orderService.stats());
});

router.post('/replay', requireInternalKey, async (req, res) => {
  res.json(await orderService.replay(req.body.orderIds));
});

module.exports = router;
