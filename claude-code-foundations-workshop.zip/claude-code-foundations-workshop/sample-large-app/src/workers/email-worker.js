const { Worker } = require('bullmq');
const { client: http } = require('../utils/http-client');
const { logger } = require('../utils/logger');
const redisConfig = require('../config/redis');

const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY;
const FROM_EMAIL = process.env.NOTIFICATIONS_FROM_EMAIL || 'noreply@example.com';

function startEmailWorker(concurrency) {
  return new Worker('emails', async (job) => {
    if (!SENDGRID_API_KEY) {
      logger.warn('email skipped — no api key');
      return;
    }
    await http.post('https://api.sendgrid.com/v3/mail/send', {
      personalizations: [{ to: [{ email: job.data.to }] }],
      from: { email: FROM_EMAIL },
      subject: job.data.subject,
      content: [{ type: 'text/html', value: job.data.body }],
    }, { headers: { Authorization: `Bearer ${SENDGRID_API_KEY}` } });
  }, {
    connection: { host: redisConfig.host, port: redisConfig.port, password: redisConfig.password },
    concurrency,
  });
}

module.exports = { startEmailWorker };
