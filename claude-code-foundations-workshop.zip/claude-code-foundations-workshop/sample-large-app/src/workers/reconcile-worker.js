const { Worker } = require('bullmq');
const { pool } = require('../db/postgres');
const { logger } = require('../utils/logger');
const redisConfig = require('../config/redis');

const BATCH_SIZE = parseInt(process.env.RECONCILE_BATCH_SIZE || '500', 10);

function startReconcileWorker(concurrency) {
  return new Worker('reconcile', async (job) => {
    logger.info('reconcile job', { id: job.id, batchSize: BATCH_SIZE });
    const r = await pool.query(
      "SELECT id FROM orders WHERE status = 'pending' AND created_at < NOW() - INTERVAL '1 hour' LIMIT $1",
      [BATCH_SIZE]
    );
    return { stale: r.rows.length };
  }, {
    connection: { host: redisConfig.host, port: redisConfig.port, password: redisConfig.password },
    concurrency,
  });
}

module.exports = { startReconcileWorker };
