const { Worker } = require('bullmq');
const paymentService = require('../services/payment-service');
const { logger } = require('../utils/logger');
const redisConfig = require('../config/redis');

function startPaymentWorker(concurrency) {
  return new Worker('payments', async (job) => {
    logger.info('payment job', { id: job.id });
    return paymentService.charge(job.data.order);
  }, {
    connection: { host: redisConfig.host, port: redisConfig.port, password: redisConfig.password },
    concurrency: parseInt(process.env.PAYMENT_WORKER_CONCURRENCY || String(concurrency), 10),
  });
}

module.exports = { startPaymentWorker };
