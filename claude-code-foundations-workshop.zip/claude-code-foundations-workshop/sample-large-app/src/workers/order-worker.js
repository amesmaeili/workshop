const { Worker } = require('bullmq');
const orderService = require('../services/order-service');
const { logger } = require('../utils/logger');
const redisConfig = require('../config/redis');

function startOrderWorker(concurrency) {
  const w = new Worker('orders', async (job) => {
    logger.info('order job', { id: job.id });
    return orderService.create(job.data.user, job.data.body);
  }, {
    connection: { host: redisConfig.host, port: redisConfig.port, password: redisConfig.password },
    concurrency,
  });
  return w;
}

module.exports = { startOrderWorker };
