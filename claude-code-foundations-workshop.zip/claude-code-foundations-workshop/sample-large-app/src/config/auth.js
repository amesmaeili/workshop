module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'dev-fallback-do-not-ship',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '24h',
  internalApiKey: process.env.INTERNAL_API_KEY,
  adminEmails: (process.env.ADMIN_EMAILS || '').split(',').map(s => s.trim()).filter(Boolean),
};
