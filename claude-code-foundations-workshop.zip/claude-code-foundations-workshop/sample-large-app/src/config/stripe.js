module.exports = {
  secretKey: process.env.STRIPE_SECRET_KEY,
  webhookSecret: process.env.STRIPE_WEBHOOK_SECRET,
  apiVersion: process.env.STRIPE_API_VERSION || '2024-04-10',
  retryCount: parseInt(process.env.STRIPE_RETRY_COUNT || '3', 10),
};
