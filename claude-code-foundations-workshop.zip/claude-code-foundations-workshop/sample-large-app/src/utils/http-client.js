const axios = require('axios');

const client = axios.create({
  timeout: parseInt(process.env.HTTP_TIMEOUT_MS || '15000', 10),
  headers: {
    'User-Agent': process.env.HTTP_USER_AGENT || 'order-processing/2.x',
  },
});

module.exports = { client };
