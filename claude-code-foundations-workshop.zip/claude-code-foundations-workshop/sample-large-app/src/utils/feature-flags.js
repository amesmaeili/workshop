const flags = {
  newCheckout: process.env.FEATURE_NEW_CHECKOUT === 'true',
  asyncRefunds: process.env.FEATURE_ASYNC_REFUNDS !== 'false',
  fraudCheck: process.env.FEATURE_FRAUD_CHECK === 'true',
  betaWebhooks: process.env.FEATURE_BETA_WEBHOOKS === 'true',
};

function isEnabled(name) {
  return Boolean(flags[name]);
}

module.exports = { flags, isEnabled };
