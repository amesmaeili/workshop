const winston = require('winston');

const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.json(),
  defaultMeta: { service: process.env.SERVICE_NAME || 'order-processing' },
  transports: [new winston.transports.Console()],
});

if (process.env.LOG_FILE) {
  logger.add(new winston.transports.File({ filename: process.env.LOG_FILE }));
}

module.exports = { logger };
