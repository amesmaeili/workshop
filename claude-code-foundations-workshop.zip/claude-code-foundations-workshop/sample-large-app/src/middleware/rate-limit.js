const { client } = require('../db/redis');

const WINDOW = parseInt(process.env.RATE_LIMIT_WINDOW_S || '60', 10);
const LIMIT = parseInt(process.env.RATE_LIMIT_MAX || '100', 10);

module.exports = async function rateLimit(req, res, next) {
  const key = `rl:${req.ip}`;
  const count = await client.incr(key);
  if (count === 1) await client.expire(key, WINDOW);
  if (count > LIMIT) return res.status(429).json({ error: 'rate limit' });
  next();
};
