const Stripe = require('stripe');
const stripeConfig = require('../config/stripe');
const { logger } = require('../utils/logger');

const stripe = new Stripe(stripeConfig.secretKey, { apiVersion: stripeConfig.apiVersion });

async function charge(order) {
  for (let attempt = 1; attempt <= stripeConfig.retryCount; attempt++) {
    try {
      const intent = await stripe.paymentIntents.create({
        amount: Math.round(order.total * 100),
        currency: process.env.DEFAULT_CURRENCY || 'usd',
        metadata: { order_id: order.id },
      });
      return intent;
    } catch (err) {
      logger.warn('charge retry', { attempt, error: err.message });
      if (attempt === stripeConfig.retryCount) throw err;
    }
  }
}

async function refund(paymentIntentId, amount) {
  return stripe.refunds.create({ payment_intent: paymentIntentId, amount });
}

module.exports = { charge, refund };
