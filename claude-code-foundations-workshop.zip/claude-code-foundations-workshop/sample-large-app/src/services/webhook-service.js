const Stripe = require('stripe');
const stripeConfig = require('../config/stripe');
const { logger } = require('../utils/logger');

const stripe = new Stripe(stripeConfig.secretKey);

async function handleStripe(rawBody, signature, secret) {
  const event = stripe.webhooks.constructEvent(rawBody, signature, secret);
  logger.info('stripe webhook', { type: event.type });
  return { received: true, type: event.type };
}

async function handleInternal(source, body) {
  if (process.env.WEBHOOK_DEBUG === 'true') logger.info('internal webhook', { source, body });
  return { received: true };
}

module.exports = { handleStripe, handleInternal };
