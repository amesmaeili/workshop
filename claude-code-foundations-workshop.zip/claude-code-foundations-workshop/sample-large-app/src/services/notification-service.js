const { client: http } = require('../utils/http-client');

const SLACK_WEBHOOK_URL = process.env.SLACK_WEBHOOK_URL;
const PAGER_DUTY_KEY = process.env.PAGER_DUTY_KEY;

async function notifySlack(message) {
  if (!SLACK_WEBHOOK_URL) return;
  await http.post(SLACK_WEBHOOK_URL, { text: message });
}

async function pageOncall(summary) {
  if (!PAGER_DUTY_KEY) return;
  await http.post('https://events.pagerduty.com/v2/enqueue', {
    routing_key: PAGER_DUTY_KEY,
    event_action: 'trigger',
    payload: { summary, severity: 'error', source: process.env.SERVICE_NAME },
  });
}

module.exports = { notifySlack, pageOncall };
