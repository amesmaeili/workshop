const { pool } = require('../db/postgres');
const { client: redis } = require('../db/redis');

const CACHE_TTL = parseInt(process.env.CUSTOMER_CACHE_TTL_S || '600', 10);

async function findById(id) {
  const cached = await redis.get(`customer:${id}`);
  if (cached) return JSON.parse(cached);
  const r = await pool.query('SELECT * FROM customers WHERE id = $1', [id]);
  if (r.rows[0]) await redis.set(`customer:${id}`, JSON.stringify(r.rows[0]), 'EX', CACHE_TTL);
  return r.rows[0];
}

async function create(body) {
  const r = await pool.query(
    'INSERT INTO customers (email, name) VALUES ($1, $2) RETURNING *',
    [body.email, body.name]
  );
  return r.rows[0];
}

module.exports = { findById, create };
