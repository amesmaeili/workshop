const { pool } = require('../db/postgres');
const paymentService = require('./payment-service');
const { isEnabled } = require('../utils/feature-flags');

async function create(user, body) {
  const r = await pool.query(
    'INSERT INTO refunds (order_id, amount, status) VALUES ($1, $2, $3) RETURNING *',
    [body.orderId, body.amount, isEnabled('asyncRefunds') ? 'queued' : 'pending']
  );
  const refund = r.rows[0];
  if (!isEnabled('asyncRefunds')) {
    await paymentService.refund(body.paymentIntentId, body.amount);
  }
  return refund;
}

async function findById(id) {
  const r = await pool.query('SELECT * FROM refunds WHERE id = $1', [id]);
  return r.rows[0];
}

module.exports = { create, findById };
