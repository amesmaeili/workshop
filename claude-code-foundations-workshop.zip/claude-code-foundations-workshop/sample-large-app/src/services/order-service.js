const { pool } = require('../db/postgres');
const { client: redis } = require('../db/redis');
const paymentService = require('./payment-service');
const { isEnabled } = require('../utils/feature-flags');
const { logger } = require('../utils/logger');

const CACHE_TTL = parseInt(process.env.ORDER_CACHE_TTL_S || '300', 10);

async function create(user, body) {
  const result = await pool.query(
    'INSERT INTO orders (user_id, total, status) VALUES ($1, $2, $3) RETURNING *',
    [user.id, body.total, 'pending']
  );
  const order = result.rows[0];
  if (isEnabled('newCheckout')) {
    await paymentService.charge(order);
  }
  return order;
}

async function findById(id, user) {
  const cached = await redis.get(`order:${id}`);
  if (cached) return JSON.parse(cached);
  const result = await pool.query('SELECT * FROM orders WHERE id = $1 AND user_id = $2', [id, user.id]);
  if (result.rows[0]) {
    await redis.set(`order:${id}`, JSON.stringify(result.rows[0]), 'EX', CACHE_TTL);
  }
  return result.rows[0];
}

async function cancel(id, user) {
  await pool.query('UPDATE orders SET status = $1 WHERE id = $2 AND user_id = $3',
    ['cancelled', id, user.id]);
  await redis.del(`order:${id}`);
  logger.info('order cancelled', { id, user: user.id });
  return { ok: true };
}

async function stats() {
  const r = await pool.query("SELECT status, count(*) FROM orders GROUP BY status");
  return r.rows;
}

async function replay(ids) {
  return { replayed: ids.length };
}

module.exports = { create, findById, cancel, stats, replay };
