const { Pool } = require('pg');
const config = require('../config/database');

const pool = new Pool({
  host: config.host,
  port: config.port,
  database: config.database,
  user: config.user,
  password: config.password,
  ssl: config.ssl ? { rejectUnauthorized: false } : false,
  min: config.pool.min,
  max: config.pool.max,
});

pool.on('error', (err) => {
  console.error('postgres pool error:', err);
});

module.exports = { pool };
