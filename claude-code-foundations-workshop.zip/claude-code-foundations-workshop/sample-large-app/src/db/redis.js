const Redis = require('ioredis');
const config = require('../config/redis');

const client = new Redis({
  host: config.host,
  port: config.port,
  password: config.password,
  db: config.db,
  tls: config.tls,
  maxRetriesPerRequest: parseInt(process.env.REDIS_MAX_RETRIES || '3', 10),
});

module.exports = { client };
