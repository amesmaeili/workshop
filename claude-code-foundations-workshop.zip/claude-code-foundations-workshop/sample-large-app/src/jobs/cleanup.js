const { pool } = require('../db/postgres');
const { logger } = require('../utils/logger');

const RETENTION_DAYS = parseInt(process.env.CLEANUP_RETENTION_DAYS || '90', 10);

async function run() {
  const r = await pool.query(
    `DELETE FROM orders WHERE status = 'cancelled' AND created_at < NOW() - INTERVAL '${RETENTION_DAYS} days'`
  );
  logger.info('cleanup', { deleted: r.rowCount });
}

module.exports = { run };
