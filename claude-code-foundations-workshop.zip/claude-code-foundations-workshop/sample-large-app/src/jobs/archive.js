const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const awsConfig = require('../config/aws');
const { pool } = require('../db/postgres');
const { logger } = require('../utils/logger');

const s3 = new S3Client({
  region: awsConfig.region,
  endpoint: awsConfig.endpoint,
  credentials: awsConfig.accessKeyId
    ? { accessKeyId: awsConfig.accessKeyId, secretAccessKey: awsConfig.secretAccessKey }
    : undefined,
});

async function run(date) {
  const r = await pool.query("SELECT * FROM orders WHERE created_at::date = $1", [date]);
  const key = `archive/${date}.json`;
  await s3.send(new PutObjectCommand({
    Bucket: awsConfig.s3Bucket,
    Key: key,
    Body: JSON.stringify(r.rows),
  }));
  logger.info('archived', { key, count: r.rows.length });
}

module.exports = { run };
