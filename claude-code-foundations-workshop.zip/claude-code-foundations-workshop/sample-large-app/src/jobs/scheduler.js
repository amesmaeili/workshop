const cleanup = require('./cleanup');
const archive = require('./archive');
const { logger } = require('../utils/logger');

const CLEANUP_HOUR = parseInt(process.env.CLEANUP_HOUR || '3', 10);
const ARCHIVE_HOUR = parseInt(process.env.ARCHIVE_HOUR || '4', 10);

setInterval(async () => {
  const now = new Date();
  if (now.getHours() === CLEANUP_HOUR && now.getMinutes() === 0) await cleanup.run();
  if (now.getHours() === ARCHIVE_HOUR && now.getMinutes() === 0) {
    const yesterday = new Date(now.getTime() - 24 * 3600 * 1000).toISOString().slice(0, 10);
    await archive.run(yesterday);
  }
}, 60 * 1000);

logger.info('scheduler started');
