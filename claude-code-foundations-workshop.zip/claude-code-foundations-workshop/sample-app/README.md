# `sample-app` — Internal Notes Service

A small Node.js + Express + SQLite service that staff use to keep shared notes. Used as the practice codebase for Modules 1, 2, 3, 4, and the capstone.

> **Heads up:** this app contains *intentional* security flaws for training purposes. Do not deploy it. Do not copy patterns from it.

## What it does

- Authenticates users (basic, very basic)
- Lets users create / read / update / delete notes
- An admin endpoint for listing all users
- Logs activity to a local file

## Stack

- Node.js + Express
- better-sqlite3 (SQLite driver)
- bcryptjs for password hashing

## Layout

```
sample-app/
├── package.json
├── server.js                 # entry point
├── src/
│   ├── routes/
│   │   ├── auth.js
│   │   ├── notes.js
│   │   └── admin.js
│   ├── db/
│   │   ├── connection.js
│   │   └── migrations.js
│   └── utils/
│       ├── logger.js
│       └── shell.js
└── tests/
    └── auth.test.js
```

## You won't run it

For this workshop, Claude Code only *reads* this codebase. You don't need Node installed.
