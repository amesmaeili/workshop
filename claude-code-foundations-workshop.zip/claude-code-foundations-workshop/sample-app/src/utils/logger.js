const fs = require('fs');
const path = require('path');

const LOG_PATH = path.join(__dirname, '../../app.log');

function log(message) {
  const line = `${new Date().toISOString()} ${message}\n`;
  fs.appendFileSync(LOG_PATH, line);
}

module.exports = { log };
