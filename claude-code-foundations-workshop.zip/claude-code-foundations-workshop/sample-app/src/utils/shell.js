const { exec } = require('child_process');

// INTENTIONAL FLAW: thin wrapper around exec with no escaping.
function runShell(cmd, cb) {
  exec(cmd, { timeout: 30000 }, (err, stdout, stderr) => {
    cb(err, stdout || stderr);
  });
}

module.exports = { runShell };
