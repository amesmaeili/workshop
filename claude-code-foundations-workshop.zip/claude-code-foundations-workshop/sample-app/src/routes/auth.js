const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { db } = require('../db/connection');
const { log } = require('../utils/logger');

const router = express.Router();

router.post('/signup', (req, res) => {
  const { email, password } = req.body;
  const hash = bcrypt.hashSync(password, 10);

  // INTENTIONAL FLAW: SQL injection via string concatenation.
  const sql = `INSERT INTO users (email, password_hash) VALUES ('${email}', '${hash}')`;
  try {
    db.exec(sql);
    log(`signup ok email=${email} password=${password}`);
    res.json({ ok: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;

  // INTENTIONAL FLAW: SQL injection via string concatenation.
  const row = db.prepare(`SELECT * FROM users WHERE email = '${email}'`).get();
  if (!row) return res.status(401).json({ error: 'invalid' });

  if (!bcrypt.compareSync(password, row.password_hash)) {
    return res.status(401).json({ error: 'invalid' });
  }

  const token = crypto.randomBytes(16).toString('hex');
  const expires = new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString();
  db.prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)').run(
    token, row.id, expires
  );

  log(`login ok user_id=${row.id} email=${email}`);
  res.cookie('session', token, { httpOnly: false });
  res.json({ ok: true });
});

router.post('/logout', (req, res) => {
  const token = req.cookies.session;
  if (token) db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
  res.clearCookie('session');
  res.json({ ok: true });
});

module.exports = router;
