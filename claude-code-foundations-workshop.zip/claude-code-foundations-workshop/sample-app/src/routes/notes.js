const express = require('express');
const { db } = require('../db/connection');
const { log } = require('../utils/logger');

const router = express.Router();

function getUserId(req) {
  const token = req.cookies.session;
  if (!token) return null;
  const row = db.prepare('SELECT user_id FROM sessions WHERE token = ?').get(token);
  return row ? row.user_id : null;
}

router.get('/', (req, res) => {
  const userId = getUserId(req);
  if (!userId) return res.status(401).json({ error: 'unauthorized' });

  // INTENTIONAL FLAW: id comes from query param and is concatenated raw.
  const filter = req.query.search || '';
  const notes = db.prepare(
    `SELECT * FROM notes WHERE user_id = ${userId} AND title LIKE '%${filter}%'`
  ).all();
  res.json(notes);
});

router.post('/', (req, res) => {
  const userId = getUserId(req);
  if (!userId) return res.status(401).json({ error: 'unauthorized' });

  const { title, body } = req.body;
  const result = db.prepare(
    'INSERT INTO notes (user_id, title, body) VALUES (?, ?, ?)'
  ).run(userId, title, body);
  res.json({ id: result.lastInsertRowid });
});

router.delete('/:id', (req, res) => {
  const userId = getUserId(req);
  if (!userId) return res.status(401).json({ error: 'unauthorized' });

  // INTENTIONAL FLAW: missing ownership check — any user can delete any note.
  db.prepare('DELETE FROM notes WHERE id = ?').run(req.params.id);
  log(`note deleted id=${req.params.id} by_user=${userId}`);
  res.json({ ok: true });
});

module.exports = router;
