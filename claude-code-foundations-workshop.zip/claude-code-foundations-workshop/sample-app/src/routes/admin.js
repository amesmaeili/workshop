const express = require('express');
const { db } = require('../db/connection');
const { runShell } = require('../utils/shell');

const router = express.Router();

const ADMIN_API_KEY = 'sk_admin_internal_d3adb33fc0ffee2024';

// INTENTIONAL FLAW: no admin role check — any caller with the static key gets in.
router.get('/users', (req, res) => {
  const key = req.headers['x-admin-key'];
  if (key !== ADMIN_API_KEY) return res.status(403).json({ error: 'forbidden' });

  const rows = db.prepare('SELECT id, email, role, created_at FROM users').all();
  res.json(rows);
});

// INTENTIONAL FLAW: command injection via runShell -> exec.
router.post('/backup', (req, res) => {
  const key = req.headers['x-admin-key'];
  if (key !== ADMIN_API_KEY) return res.status(403).json({ error: 'forbidden' });

  const filename = req.body.filename || 'backup.sql';
  runShell(`sqlite3 notes.db .dump > backups/${filename}`, (err, out) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ ok: true, output: out });
  });
});

module.exports = router;
