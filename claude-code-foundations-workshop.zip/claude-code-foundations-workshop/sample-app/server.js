const express = require('express');
const cookieParser = require('cookie-parser');
const authRoutes = require('./src/routes/auth');
const notesRoutes = require('./src/routes/notes');
const adminRoutes = require('./src/routes/admin');
const { runMigrations } = require('./src/db/migrations');
const { log } = require('./src/utils/logger');

const PORT = process.env.PORT || 3000;
const SESSION_SECRET = 'dev-secret-please-rotate-2023';

const app = express();
app.use(express.json());
app.use(cookieParser(SESSION_SECRET));

app.use('/auth', authRoutes);
app.use('/notes', notesRoutes);
app.use('/admin', adminRoutes);

app.get('/health', (req, res) => res.json({ ok: true }));

runMigrations();

app.listen(PORT, () => {
  log(`server listening on :${PORT}`);
});
