# Pre-Flight — Do This 1 Week Before the Workshop

Total time: ~15 minutes. Do this on the same laptop you'll bring to the workshop.

The 2-hour workshop is tight; we won't spend time installing tools. If you walk in without these steps done, you'll fall behind.

---

## 1. Install Claude Code (~5 min)

Pick the path for your OS:

### macOS / Linux

```bash
curl -fsSL https://claude.com/install.sh | bash
```

This installs the `claude` CLI and adds it to your PATH. Restart your shell.

### Windows

Use WSL2 with a Linux distribution (Ubuntu recommended), then follow the macOS/Linux instructions above inside WSL. Native Windows is not officially supported for this workshop.

### Verify

```bash
claude --version
```

You should see a version number. If not, see **Troubleshooting** at the bottom.

---

## 2. Authenticate (~5 min)

Run `claude` once in any directory:

```bash
mkdir -p ~/claude-warmup && cd ~/claude-warmup
claude
```

Claude Code will open a browser for you to log in. Use the account your organization provided (or your personal Anthropic account if your org doesn't have one).

Once authenticated, the REPL prompt will appear. Type a quick test prompt:

```
Hi, are you working?
```

You should get a response. Then type `/exit`.

> If your organization uses an API key or Bedrock/Vertex routing instead of browser auth, your IT team will have given you separate setup instructions. Follow those.

---

## 3. Clone the Workshop Repository (~2 min)

```bash
git clone <REPO-URL> claude-code-foundations-workshop
cd claude-code-foundations-workshop
```

> Replace `<REPO-URL>` with the URL the instructor sends you.

---

## 4. Verify the Sample Apps (~3 min)

The workshop ships two sample codebases. Make sure both are present:

```bash
ls sample-app/         # should show README.md, package.json, src/, etc.
ls sample-large-app/   # should show README.md, package.json, src/, etc.
```

You do **not** need to `npm install` or run them — we're not executing code. Claude Code only reads them.

---

## 5. Final Verification — Do This Last

```bash
cd claude-code-foundations-workshop/sample-app
claude
```

In the REPL, type:

```
Read README.md and tell me in one sentence what this app does.
```

Claude should call its `Read` tool, read the file, and respond. If you see this happen, you're ready.

Type `/exit`.

---

## Troubleshooting

**`claude: command not found` after install**
- Restart your shell (close terminal, reopen) or run `source ~/.zshrc` / `source ~/.bashrc`.
- Check `echo $PATH` includes `~/.local/bin` (macOS/Linux) or wherever the installer put the binary.

**Browser auth fails / loops**
- Use a different browser (Chrome works most reliably).
- Disable VPN temporarily during auth.
- Clear cookies for `claude.com`.

**Corporate firewall blocks the REPL**
- Get your IT team involved early — `*.anthropic.com` and `*.claude.com` need to be allowlisted.
- This is the #1 reason people walk into the workshop unable to participate. Test from your work network, not just home wifi.

**REPL works but tool calls fail (e.g., `Read` errors)**
- Make sure you're inside `claude-code-foundations-workshop/sample-app/` when you run `claude`. The REPL's working directory matters.
- Run `claude --version` again — if it's pre-1.0, update.

---

## Day-of-Workshop Reminders

- Bring your laptop charged + power adapter.
- Make sure you have terminal access (no admin restrictions on running `claude`).
- Have a markdown editor / your normal editor open alongside the terminal — you'll be editing files during labs.
