# Claude Code Foundations — Workshop 1

A 2h 25min, hands-on workshop for **security engineers** who have never used Claude Code. By the end you'll be comfortable with the primitives — permissions, context, slash commands, hooks, subagents, MCPs, and plugins — that power agentic security tooling like the AITM threat-modeling plugin (Workshop 2).

> **You'll learn the tool. Workshop 2 will use it for threat modeling.**

---

## Prerequisites

You should be comfortable with the terminal, scripting, and git, and have used a chat-based LLM tool (ChatGPT / Cursor / Copilot) at least casually. You do NOT need prior Claude Code experience.

Before the workshop, complete the steps in **[PREFLIGHT.md](./PREFLIGHT.md)** (sent 1 week ahead). It takes ~15 minutes and ensures you're ready to participate.

---

## Schedule (145 minutes)

| Slot | Module | Time |
|------|--------|------|
| — | Intro: what is Claude Code | 5 min |
| 0 | [Driving the REPL](./modules/00-commands/CHEATSHEET.md) — slash commands + input shortcuts | 15 min |
| 1 | [Mechanics](./modules/01-mechanics/) — agentic loop + reading code | 18 min |
| 2 | [Trust](./modules/02-trust/) — permissions + settings.json | 18 min |
| 3 | [Context](./modules/03-context/) — CLAUDE.md + context engineering | 18 min |
| 4 | [Extensibility](./modules/04-extensibility/) — slash commands + hooks | 18 min |
| 5 | [Delegation](./modules/05-delegation/) — subagents + MCP servers | 23 min |
| 6 | [Capstone](./modules/06-capstone/) — install & dissect a plugin | 25 min |
| — | Wrap-up + Workshop 2 preview | 5 min |

Most modules follow the same rhythm: instructor presents the concept (≈5–9 min), then you do a lab (≈8–14 min). Acceptance criteria are explicit — you finish a lab when the named output file exists with the right content. **Module 0 is the exception**: it's a guided live-along with no lab — the takeaway is the cheatsheet.

---

## How to Use This Repository

```
claude-code-foundations-workshop/
├── README.md            <- you are here
├── PREFLIGHT.md         <- pre-workshop setup (do this first)
├── docs/SPEC.md         <- design document (for instructors)
├── slides/              <- presentation (Marp markdown + PDF)
├── modules/             <- lab instructions + starter files
├── answers/             <- DO NOT OPEN until you've attempted the lab
├── sample-app/          <- shared codebase used by Modules 1-4 + capstone
└── sample-large-app/    <- larger codebase used by Module 5
```

**Workflow per module:**
1. Listen to the instructor's presentation.
2. Open `modules/<NN-name>/README.md` and follow the lab steps.
3. Work in `modules/<NN-name>/lab/` (your starter files live there).
4. When you hit the acceptance criterion (or get stuck for 5 minutes), open `answers/<NN-name>/SOLUTION.md`.
5. Move on.

**Module 0 exception:** no `README.md`, no `lab/`, no `answers/`. It's a live-along — the instructor demos commands, you run them in real time. Reference: `modules/00-commands/CHEATSHEET.md`.

**Rule of thumb:** if you're stuck for more than 5 minutes, open the answer. The point is to *learn the primitive*, not to grind on syntax.

---

## Setup Verification

If you completed [PREFLIGHT.md](./PREFLIGHT.md), this should work:

```bash
cd claude-code-foundations-workshop/sample-app
claude --version          # should print a version
claude                    # should drop you into the REPL — type /exit to leave
```

If either command fails, see PREFLIGHT.md's troubleshooting section.

---

## After the Workshop

- Workshop 2 — Threat Modeling with the AITM Plugin will use everything you learned here.
- The `answers/` folder doubles as a reference: when you're back at your desk and forget how a custom slash command's frontmatter looks, peek there.
- Real Claude Code docs: [docs.claude.com/en/docs/claude-code](https://docs.claude.com/en/docs/claude-code)

---

## For Instructors

- The design spec is at `docs/SPEC.md`.
- Slides source: `slides/claude-code-foundations.md` (Marp).
- Two open instructor-side tasks are flagged in the spec (Section 9): swap in your org's Sunrise MCP install steps before delivering Module 5B; tailor PREFLIGHT.md for your org's auth posture.
